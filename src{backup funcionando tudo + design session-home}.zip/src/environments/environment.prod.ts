export const environment = {
  production: true,
  // IMPORTANTE: Substitua esta URL pela URL do seu ngrok quando for fazer build para Android
  // Exemplo: 'https://abc123.ngrok.io'
  serverUrl: 'https://be10d1c7a850.ngrok-free.app'
};
