import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Platform } from '@ionic/angular';

@Injectable()
export class AndroidHttpInterceptor implements HttpInterceptor {
  
  constructor(private platform: Platform) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Aplicar modificações específicas para Android
    if (this.platform.is('android') || this.platform.is('capacitor')) {
      console.log('🤖 AndroidHttpInterceptor: Aplicando configurações para Android');
      
      let modifiedRequest = request.clone({
        setHeaders: {
          // Headers específicos para Android/Capacitor
          'Accept': 'application/json, text/plain, */*',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });

      // Para requisições ngrok, adicionar header específico
      if (request.url.includes('ngrok')) {
        modifiedRequest = modifiedRequest.clone({
          setHeaders: {
            'ngrok-skip-browser-warning': 'true',
            'User-Agent': 'PizzaDayApp/1.0 (Android)'
          }
        });
      }

      console.log('📋 Request modificado para Android:', {
        url: modifiedRequest.url,
        headers: modifiedRequest.headers.keys().map(key => ({
          [key]: modifiedRequest.headers.get(key)
        }))
      });

      return next.handle(modifiedRequest);
    }

    // Para outras plataformas, passar sem modificação
    return next.handle(request);
  }
}
