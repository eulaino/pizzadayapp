import { Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { Observable } from 'rxjs';
import { PlatformService } from './platform.service';

// Interface para um participante da sala.
export interface Participant {
  author: string;
  pizza: number;
  isHost: boolean;
  roomId: string;
  socketId?: string;
  cpf?: string;
}

@Injectable({
  providedIn: 'root'
})
export class SocketService {
  private socket: Socket;
  private readonly SOCKET_URL: string;
  public currentRoomId: string | null = null;
  public currentUsername: string | null = null;

  public getSocket(): Socket {
    return this.socket;
  }

  constructor(private platformService: PlatformService) {
    this.SOCKET_URL = this.platformService.getServerUrl();
    this.socket = io(this.SOCKET_URL, {
      transports: ['websocket', 'polling'], // Fallback para polling se websocket falhar
      timeout: 20000,
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
      forceNew: true
    });

    console.log('Tentando conectar ao socket em:', this.SOCKET_URL);

    this.socket.on('connect', () => {
      console.log('✅ Conectado ao servidor Socket.IO com ID:', this.socket.id);
      console.log('🔗 Transporte usado:', this.socket.io.engine.transport.name);
    });

    this.socket.on('connect_error', (err) => {
      console.error('❌ Erro ao conectar:', err.message);
      console.error('📍 URL tentativa:', this.SOCKET_URL);
      console.error('🔍 Detalhes completos:', err);
    });

    this.socket.on('disconnect', (reason) => {
      console.warn('⚠️ Desconectado:', reason);
    });

    this.socket.on('reconnect', (attemptNumber) => {
      console.log('🔄 Reconectado após', attemptNumber, 'tentativas');
    });

    this.socket.on('reconnect_attempt', (attemptNumber) => {
      console.log('🔄 Tentativa de reconexão:', attemptNumber);
    });

    this.socket.on('reconnect_failed', () => {
      console.error('❌ Falha ao reconectar após todas as tentativas');
    });
  }

  // --- Métodos para Emitir Eventos (Enviar para o Servidor) ---
  emit(eventName: string, data?: any) {
    console.log(`[SocketService] -> Emitindo '${eventName}' com dados:`, data);
    this.socket.emit(eventName, data);
  }

  // Método para verificar status de host
  requestHostStatus(roomId: string, username?: string) {
    const usernameToCheck = username || this.currentUsername;
    if (usernameToCheck) {
      console.log(`[SocketService] Solicitando verificação de host: Sala=${roomId}, Nome=${usernameToCheck}`);
      // Envia ambos os campos para compatibilidade com o servidor
      this.emit('checkIfHost', { roomId, username: usernameToCheck, userId: usernameToCheck });
    } else {
      console.warn('[SocketService] Username não disponível para verificação de host');
    }
  }

  // Método para solicitar status da sala
  requestRoomStatus(roomId: string) {
    console.log(`[SocketService] Solicitando status da sala: ${roomId}`);
    this.emit('requestRoomStatus', { roomId });
  }

  // Método para verificar se o usuário atual é host
  checkCurrentUserHost(roomId: string) {
    if (this.currentUsername) {
      console.log(`[SocketService] Verificando se ${this.currentUsername} é host da sala ${roomId}`);
      // Envia ambos os campos para compatibilidade com o servidor
      this.emit('checkCurrentUserHost', { roomId, username: this.currentUsername, userId: this.currentUsername });
    }
  }

  joinRoom(roomId: string, cpf: string, displayName?: string) {
    console.log(`[SocketService] joinRoom chamado: roomId=${roomId}, cpf=${cpf}, displayName=${displayName}`);
    console.log(`[SocketService] Socket conectado: ${this.socket.connected}`);
    
    // Sempre atualizar as variáveis de sessão
    this.currentRoomId = roomId;
    this.currentUsername = cpf;

    // Envia todos os identificadores para evitar incompatibilidades do backend
    const joinData = { roomId, username: cpf, userId: cpf, cpf, displayName: displayName || cpf };
    console.log('[SocketService] Enviando joinRoom:', joinData);
    this.emit('joinRoom', joinData);
    
    // Verificar status de host imediatamente após joinRoom
    setTimeout(() => {
      console.log('[SocketService] Verificando status de host após joinRoom...');
      this.checkCurrentUserHost(roomId);
      this.requestHostStatus(roomId, cpf);
    }, 1000);
  }

  sendMessage(author: string, pizza: number, roomId: string) {
    console.log(`[SocketService] Tentando sendMessage: Autor=${author}, Pizza=${pizza}, Sala=${roomId}`);
    this.emit('sendMessage', { author, pizza, roomId });
  }

  removeSliceRequest(roomId: string, authorToChange: string) {
    console.log(`[SocketService] Tentando removeSliceRequest: Sala=${roomId}, Alterar=${authorToChange}`);
    this.emit('removeSliceRequest', { roomId, authorToChange });
  }

  leaveRoom(roomId: string) {
    console.log(`[SocketService] Tentando leaveRoom: Sala=${roomId}`);
    this.emit('leaveRoom', roomId);
  }

  resetSessionState(roomId: string) {
    if (this.currentRoomId === roomId) {
      this.currentRoomId = null;
      this.currentUsername = null;
    }
  }

  // --- Métodos para Ouvir Eventos (Receber do Servidor) ---
  listen(eventName: string): Observable<any> {
    return new Observable((subscriber) => {
      this.socket.on(eventName, (data?: any) => {
        console.log(`[SocketService] <- Recebido '${eventName}':`, data);
        subscriber.next(data);
      });
      
      // Log quando o listener é criado
      console.log(`[SocketService] Listener criado para evento: ${eventName}`);
      
      return () => {
        console.log(`[SocketService] Listener removido para evento: ${eventName}`);
        this.socket.off(eventName);
      };
    });
  }

  onPreviousMessages(): Observable<Participant[]> {
    return this.listen('previousMessages');
  }

  onReceivedMessage(): Observable<Participant> {
    return this.listen('receivedMessage');
  }

  onJoinError(): Observable<string> {
    return this.listen('joinError');
  }

  onYouAreHost(): Observable<{ isHost: boolean }> {
    return this.listen('youAreHost');
  }

  onHostTransferred(): Observable<{ newHost: string }> {
    return this.listen('hostTransferred');
  }

  onUserLeft(): Observable<{ author: string; roomId: string }> {
    return this.listen('userLeft');
  }

  onError(): Observable<string> {
    return this.listen('error');
  }

  // Novos listeners para resolver o problema do host
  onRoomJoined(): Observable<{ roomId: string; participants: Participant[]; isHost?: boolean }> {
    return this.listen('roomJoined');
  }

  onRoomStatusResponse(): Observable<{ roomId: string; participants: Participant[]; userIsHost: boolean }> {
    return this.listen('roomStatusResponse');
  }

  onUserHostStatus(): Observable<{ roomId: string; username: string; isHost: boolean }> {
    return this.listen('userHostStatus');
  }

  // Listener para mudanças de status de host
  onHostStatusChanged(): Observable<{ roomId: string; newHost: string; action: string }> {
    return this.listen('hostStatusChanged');
  }

  // Listener para verificações de host forçadas
  onForceHostCheck(): Observable<{ roomId: string; isHost: boolean }> {
    return this.listen('forceHostCheck');
  }



  // Métodos utilitários
  isConnected(): boolean {
    return this.socket.connected;
  }

  reconnect() {
    if (!this.socket.connected) {
      console.log('[SocketService] Tentando reconectar...');
      this.socket.connect();
    }
  }

  getConnectionInfo() {
    return {
      connected: this.socket.connected,
      currentRoomId: this.currentRoomId,
      currentUsername: this.currentUsername,
      socketId: this.socket.id
    };
  }
}
