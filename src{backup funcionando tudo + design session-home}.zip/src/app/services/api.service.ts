import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { PlatformService } from './platform.service';
import { Observable, throwError } from 'rxjs';
import { catchError, timeout } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly API_NGROK = 'https://be10d1c7a850.ngrok-free.app/api';
  private readonly API_LOCAL = 'http://localhost:3000/api';
  private readonly API: string;

  constructor(private http: HttpClient, private platformService: PlatformService) {
    this.API = `${this.platformService.getServerUrl()}/api`;
    console.log('🔗 ApiService inicializado com URL:', this.API);
    console.log('📱 Plataforma info:', this.platformService.getPlatformInfo());
  }

  private getHttpHeaders(): HttpHeaders {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    // Para ngrok, adicionar headers necessários
    if (this.API.includes('ngrok')) {
      headers = headers.set('ngrok-skip-browser-warning', 'true');
    }

    return headers;
  }

  private handleError(error: any): Observable<never> {
    console.error('❌ Erro HTTP detalhado:', {
      status: error.status,
      statusText: error.statusText,
      message: error.message,
      url: error.url,
      error: error.error
    });
    return throwError(() => error);
  }

  salvarUsuario(username: string, roomId: string, nome: string) {
    const url = `${this.API}/usuarios`;
    const headers = this.getHttpHeaders();
    console.log(`🌐 API URL: ${url}`);
    console.log(`📋 Headers:`, headers);
    
    return this.http.post(url, { username, roomId, nome }, { headers })
      .pipe(
        timeout(10000), // 10 segundos timeout
        catchError(this.handleError.bind(this))
      );
  }

  buscarUsuarioPorCpf(cpf: string) {
    const url = `${this.API}/usuarios/${cpf}`;
    const headers = this.getHttpHeaders();
    console.log(`🔍 Buscando CPF na URL: ${url}`);
    console.log(`📋 Headers:`, headers);
    
    return this.http.get<any>(url, { headers })
      .pipe(
        timeout(8000), // 8 segundos timeout
        catchError(this.handleError.bind(this))
      );
  }

  // Método para testar conectividade
  async testarConectividade(): Promise<{ ngrok: boolean; local: boolean }> {
    const resultado = { ngrok: false, local: false };
    const headers = this.getHttpHeaders();

    // Testar ngrok
    try {
      await this.http.get(`${this.API_NGROK}/usuarios/test`, { headers })
        .pipe(timeout(5000))
        .toPromise();
      resultado.ngrok = true;
      console.log('✅ Ngrok disponível');
    } catch (error) {
      console.log('❌ Ngrok não disponível:', error);
    }

    // Testar local
    try {
      await this.http.get(`${this.API_LOCAL}/usuarios/test`, { headers })
        .pipe(timeout(5000))
        .toPromise();
      resultado.local = true;
      console.log('✅ Servidor local disponível');
    } catch (error) {
      console.log('❌ Servidor local não disponível:', error);
    }

    return resultado;
  }
}