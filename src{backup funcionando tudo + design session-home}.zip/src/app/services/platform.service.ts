import { Injectable } from '@angular/core';
import { Platform } from '@ionic/angular';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PlatformService {
  
  constructor(private platform: Platform) {}

  /**
   * Retorna a URL do servidor baseada na plataforma
   * - Web: usa localhost
   * - Mobile: usa a URL do environment (ngrok)
   */
  getServerUrl(): string {
    if (this.platform.is('hybrid')) {
      // Rodando no dispositivo móvel (Android/iOS)
      console.log('🤖 Plataforma detectada: Mobile - usando URL do environment');
      return environment.serverUrl;
    } else {
      // Rodando no browser
      console.log('🌐 Plataforma detectada: Web - usando localhost');
      return 'http://localhost:3000';
    }
  }

  /**
   * Verifica se está rodando em um dispositivo móvel
   */
  isMobile(): boolean {
    return this.platform.is('hybrid');
  }

  /**
   * Verifica se está rodando no browser
   */
  isWeb(): boolean {
    return !this.platform.is('hybrid');
  }

  /**
   * Retorna informações sobre a plataforma
   */
  getPlatformInfo() {
    return {
      isMobile: this.isMobile(),
      isWeb: this.isWeb(),
      platforms: this.platform.platforms(),
      serverUrl: this.getServerUrl()
    };
  }
}
