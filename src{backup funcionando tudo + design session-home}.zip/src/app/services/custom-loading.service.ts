import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface LoadingState {
  isVisible: boolean;
  message: string;
  spinnerType: string;
}

@Injectable({
  providedIn: 'root'
})
export class CustomLoadingService {
  private loadingState = new BehaviorSubject<LoadingState>({
    isVisible: false,
    message: 'Carregando...',
    spinnerType: 'dots'
  });

  public loadingState$ = this.loadingState.asObservable();

  constructor() { }

  show(message: string = 'Carregando...', spinnerType: string = 'dots') {
    console.log('📱 Mostrando loading customizado:', message);
    this.loadingState.next({
      isVisible: true,
      message,
      spinnerType
    });
  }

  hide() {
    console.log('📱 Escondendo loading customizado');
    this.loadingState.next({
      isVisible: false,
      message: '',
      spinnerType: 'dots'
    });
  }

  updateMessage(message: string) {
    const currentState = this.loadingState.value;
    if (currentState.isVisible) {
      this.loadingState.next({
        ...currentState,
        message
      });
    }
  }
}
