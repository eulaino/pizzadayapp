import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformService } from './platform.service';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ConnectivityTestService {

  constructor(
    private http: HttpClient, 
    private platformService: PlatformService
  ) {}

  /**
   * Testa a conectividade com o servidor
   */
  async testConnectivity(): Promise<{
    success: boolean;
    serverUrl: string;
    platformInfo: any;
    error?: string;
  }> {
    const serverUrl = this.platformService.getServerUrl();
    const platformInfo = this.platformService.getPlatformInfo();

    console.log('🧪 Testando conectividade...');
    console.log('📍 URL do servidor:', serverUrl);
    console.log('🤖 Informações da plataforma:', platformInfo);

    try {
      // Tenta fazer uma requisição HTTP simples para testar conectividade
      const testUrl = `${serverUrl}/api/room-status/test`;
      
      await firstValueFrom(this.http.get(testUrl, { 
        timeout: 10000,
        responseType: 'text'
      }));

      console.log('✅ Conectividade HTTP OK');
      
      return {
        success: true,
        serverUrl,
        platformInfo
      };

    } catch (error: any) {
      console.error('❌ Erro de conectividade:', error);
      
      return {
        success: false,
        serverUrl,
        platformInfo,
        error: error.message || 'Erro desconhecido'
      };
    }
  }

  /**
   * Testa especificamente a conexão WebSocket
   */
  async testWebSocketConnectivity(): Promise<{
    success: boolean;
    transport?: string;
    error?: string;
  }> {
    return new Promise((resolve) => {
      const serverUrl = this.platformService.getServerUrl();
      
      console.log('🧪 Testando WebSocket...');
      
      // Importa socket.io dinamicamente para evitar problemas de bundling
      import('socket.io-client').then(({ io }) => {
        const testSocket = io(serverUrl, {
          transports: ['websocket', 'polling'],
          timeout: 10000,
          reconnection: false
        });

        const timeoutId = setTimeout(() => {
          testSocket.disconnect();
          resolve({
            success: false,
            error: 'Timeout - não foi possível conectar em 10 segundos'
          });
        }, 10000);

        testSocket.on('connect', () => {
          clearTimeout(timeoutId);
          const transport = testSocket.io.engine.transport.name;
          console.log('✅ WebSocket conectado usando:', transport);
          
          testSocket.disconnect();
          resolve({
            success: true,
            transport
          });
        });

        testSocket.on('connect_error', (error) => {
          clearTimeout(timeoutId);
          console.error('❌ Erro WebSocket:', error);
          
          testSocket.disconnect();
          resolve({
            success: false,
            error: error.message || 'Erro de conexão WebSocket'
          });
        });
      });
    });
  }

  /**
   * Executa todos os testes de conectividade
   */
  async runFullConnectivityTest() {
    console.log('🚀 Iniciando teste completo de conectividade...');
    
    const httpTest = await this.testConnectivity();
    const wsTest = await this.testWebSocketConnectivity();

    const result = {
      timestamp: new Date().toISOString(),
      platform: this.platformService.getPlatformInfo(),
      http: httpTest,
      websocket: wsTest,
      overall: httpTest.success && wsTest.success
    };

    console.log('📊 Resultado completo dos testes:', result);
    
    return result;
  }
}
