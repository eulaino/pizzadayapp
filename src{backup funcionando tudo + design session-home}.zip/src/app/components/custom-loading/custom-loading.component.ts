import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonSpinner } from '@ionic/angular/standalone';

@Component({
  selector: 'app-custom-loading',
  template: `
    <div *ngIf="isVisible" class="custom-loading-overlay">
      <div class="custom-loading-container">
        <ion-spinner [name]="spinnerType" color="light"></ion-spinner>
        <p class="loading-message">{{ message }}</p>
      </div>
    </div>
  `,
  styles: [`
    .custom-loading-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }
    
    .custom-loading-container {
      background-color: rgba(0, 0, 0, 0.8);
      padding: 30px;
      border-radius: 15px;
      text-align: center;
      min-width: 200px;
    }
    
    .loading-message {
      color: white;
      margin-top: 15px;
      font-size: 16px;
      font-weight: 500;
    }
    
    ion-spinner {
      width: 40px;
      height: 40px;
    }
  `],
  standalone: true,
  imports: [CommonModule, IonSpinner]
})
export class CustomLoadingComponent {
  @Input() isVisible: boolean = false;
  @Input() message: string = 'Carregando...';
  @Input() spinnerType: string = 'dots';
}
