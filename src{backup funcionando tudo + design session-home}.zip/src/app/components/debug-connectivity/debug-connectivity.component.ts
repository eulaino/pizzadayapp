import { Component } from '@angular/core';
import { ConnectivityTestService } from '../../services/connectivity-test.service';
import { PlatformService } from '../../services/platform.service';
import { ApiService } from '../../services/api.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-debug-connectivity',
  template: `
    <ion-card>
      <ion-card-header>
        <ion-card-title>🔧 Debug de Conectividade</ion-card-title>
      </ion-card-header>
      
      <ion-card-content>
        <div class="platform-info">
          <h4>📱 Informações da Plataforma</h4>
          <p><strong>Plataforma:</strong> {{ platformInfo.isMobile ? 'Mobile' : 'Web' }}</p>
          <p><strong>URL do Servidor:</strong> {{ platformInfo.serverUrl }}</p>
          <p><strong>Plataformas:</strong> {{ platformInfo.platforms.join(', ') }}</p>
        </div>

        <div class="test-buttons">
          <ion-button 
            expand="block" 
            fill="outline" 
            (click)="testHTTP()"
            [disabled]="testing">
            <ion-icon name="globe" slot="start"></ion-icon>
            Testar HTTP
          </ion-button>

          <ion-button 
            expand="block" 
            fill="outline" 
            (click)="testWebSocket()"
            [disabled]="testing">
            <ion-icon name="flash" slot="start"></ion-icon>
            Testar WebSocket
          </ion-button>

          <ion-button 
            expand="block" 
            fill="outline" 
            color="secondary"
            (click)="testCpfApi()"
            [disabled]="testing">
            <ion-icon name="person" slot="start"></ion-icon>
            Testar API CPF
          </ion-button>

          <ion-button 
            expand="block" 
            color="primary"
            (click)="runFullTest()"
            [disabled]="testing">
            <ion-icon name="checkmark-circle" slot="start"></ion-icon>
            {{ testing ? 'Testando...' : 'Teste Completo' }}
          </ion-button>
        </div>

        <div *ngIf="lastTestResult" class="test-result">
          <h4>📊 Último Resultado</h4>
          <ion-chip [color]="lastTestResult.overall ? 'success' : 'danger'">
            {{ lastTestResult.overall ? '✅ Sucesso' : '❌ Falha' }}
          </ion-chip>
          <p><small>{{ lastTestResult.timestamp | date:'medium' }}</small></p>
        </div>
      </ion-card-content>
    </ion-card>
  `,
  styles: [`
    .platform-info {
      margin-bottom: 20px;
      padding: 10px;
      background: var(--ion-color-light);
      border-radius: 8px;
    }
    
    .test-buttons ion-button {
      margin-bottom: 10px;
    }
    
    .test-result {
      margin-top: 20px;
      padding: 10px;
      border: 1px solid var(--ion-color-medium);
      border-radius: 8px;
    }
  `]
})
export class DebugConnectivityComponent {
  platformInfo: any;
  testing = false;
  lastTestResult: any = null;

  constructor(
    private connectivityTest: ConnectivityTestService,
    private platformService: PlatformService,
    private apiService: ApiService,
    private alertController: AlertController
  ) {
    this.platformInfo = this.platformService.getPlatformInfo();
  }

  async testHTTP() {
    this.testing = true;
    try {
      const result = await this.connectivityTest.testConnectivity();
      await this.showResult('Teste HTTP', result.success, result.error);
    } finally {
      this.testing = false;
    }
  }

  async testWebSocket() {
    this.testing = true;
    try {
      const result = await this.connectivityTest.testWebSocketConnectivity();
      await this.showResult('Teste WebSocket', result.success, result.error);
    } finally {
      this.testing = false;
    }
  }

  async testCpfApi() {
    this.testing = true;
    try {
      // Testar com um CPF de exemplo
      const cpfTeste = '12345678901';
      console.log('🧪 Testando API de busca por CPF:', cpfTeste);
      
      const result = await this.apiService.buscarUsuarioPorCpf(cpfTeste).toPromise();
      console.log('✅ Resposta da API CPF:', result);
      
      await this.showResult(
        'Teste API CPF', 
        true, 
        `CPF testado: ${cpfTeste}<br>Resposta: ${JSON.stringify(result, null, 2)}`
      );
    } catch (error: any) {
      console.error('❌ Erro no teste da API CPF:', error);
      
      let errorMessage = `Erro: ${error.status || 'N/A'}<br>`;
      errorMessage += `Mensagem: ${error.message || 'Erro desconhecido'}<br>`;
      errorMessage += `URL: ${error.url || 'N/A'}`;
      
      await this.showResult('Teste API CPF', false, errorMessage);
    } finally {
      this.testing = false;
    }
  }

  async runFullTest() {
    this.testing = true;
    try {
      const result = await this.connectivityTest.runFullConnectivityTest();
      this.lastTestResult = result;
      
      const message = [
        `HTTP: ${result.http.success ? '✅' : '❌'}`,
        `WebSocket: ${result.websocket.success ? '✅' : '❌'}`,
        result.websocket.transport ? `Transporte: ${result.websocket.transport}` : '',
        result.http.error || result.websocket.error || ''
      ].filter(Boolean).join('<br>');

      await this.showResult('Teste Completo', result.overall, message);
    } finally {
      this.testing = false;
    }
  }

  private async showResult(title: string, success: boolean, details?: string) {
    const alert = await this.alertController.create({
      header: title,
      subHeader: success ? '✅ Sucesso' : '❌ Falha',
      message: details || (success ? 'Conectividade OK!' : 'Erro de conectividade'),
      buttons: ['OK']
    });
    await alert.present();
  }
}
