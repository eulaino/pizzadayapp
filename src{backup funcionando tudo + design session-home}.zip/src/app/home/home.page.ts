import { Component, OnInit, OnDestroy } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { SocketService } from '../services/socket.service';
import { AlertController, NavController, LoadingController, Platform } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { CustomLoadingService, LoadingState } from '../services/custom-loading.service';
import { ChangeDetectorRef } from '@angular/core';
import { ZXingScannerModule } from '@zxing/ngx-scanner';
import { QRCodeComponent } from 'angularx-qrcode';
import { BarcodeFormat } from '@zxing/library';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonIcon,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonFooter,
  IonList,
  IonItem,
  IonInput,
  IonButton
} from '@ionic/angular/standalone';
import { CustomLoadingComponent } from '../components/custom-loading/custom-loading.component';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    QRCodeComponent,
    ZXingScannerModule,
    CustomLoadingComponent,
    IonHeader,
    IonToolbar,
    IonIcon,
    IonTitle,
    IonContent,
    IonFooter,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonList,
    IonItem,
    IonInput,
    IonButton
  ]
})
export class HomePage implements OnInit, OnDestroy {
  barcodeFormats = [BarcodeFormat.QR_CODE];
  showScanner = false;
  anfitriaoBox = false;
  usuarioBox = false;
  errorMessage: string = '';
  pulse = false;
  animatePop = false;

  // Pizza Modern UI States
  cpfFocused = false;
  nomeFocused = false;
  sessionFocused = false;
  logoAnimated = false;
  titleAnimated = false;

  private subscriptions: Subscription = new Subscription();
  private currentLoading: HTMLIonLoadingElement | null = null;

  loginForm!: FormGroup;
  nomeCarregado: boolean = false;
  buscandoNome: boolean = false;
  customLoadingState: LoadingState = {
    isVisible: false,
    message: 'Carregando...',
    spinnerType: 'dots'
  };

  constructor(
    private socketService: SocketService,
    private router: Router,
    private alertController: AlertController,
    private navCtrl: NavController,
    private cdr: ChangeDetectorRef,
    private api: ApiService,
    private fb: FormBuilder,
    private loadingController: LoadingController,
    private platform: Platform,
    private customLoadingService: CustomLoadingService
  ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      cpf: ['', [Validators.required, Validators.pattern(/^\d{11}$/)]],
      nome: ['', Validators.required],
      sessionId: ['', [Validators.required, Validators.minLength(8)]]
    });

    // Observa as mudanças no campo CPF para buscar o nome
    this.loginForm.get('cpf')?.valueChanges
      .pipe(
        debounceTime(500), // Reduzido para ser mais responsivo
        distinctUntilChanged()
      )
      .subscribe(cpf => {
        console.log('🎯 CPF alterado:', cpf, 'Length:', cpf?.length, 'Type:', typeof cpf);

        // Limpar caracteres não numéricos
        const cleanCpf = cpf ? cpf.toString().replace(/\D/g, '') : '';
        console.log('🧹 CPF limpo:', cleanCpf);

        if (cleanCpf && cleanCpf.length === 11) {
          console.log('✅ CPF válido, iniciando busca...');
          this.buscarNomePorCpf(cleanCpf);
        } else {
          console.log('❌ CPF inválido ou incompleto, limpando dados...');
          // Limpar dados quando CPF for inválido ou incompleto
          this.loginForm.get('nome')?.setValue('');
          this.loginForm.get('nome')?.enable();
          this.nomeCarregado = false;
          this.buscandoNome = false;
          this.errorMessage = '';
        }
      });

    // Listener para erros de entrada na sala
    this.subscriptions.add(this.socketService.onJoinError().subscribe(async (message) => {
      console.log('❌ Erro ao entrar na sala:', message);
      await this.dismissLoading();
      setTimeout(() => {
        this.presentAlert('Erro ao Entrar', message || 'Não foi possível entrar na sala.');
      }, 100);
    }));

    // Listener para mensagens anteriores (sucesso na entrada)
    this.subscriptions.add(this.socketService.onPreviousMessages().subscribe(async (messages) => {
      console.log('📨 Recebido previousMessages:', messages?.length || 0, 'mensagens');
      await this.dismissLoading();
      const { sessionId, cpf, nome } = this.loginForm.getRawValue();
      console.log('✅ Sucesso! Navegando para session-room...');
      this.navigateToSession(sessionId, cpf, nome, messages);
    }));

    // Subscribe ao estado do loading customizado
    this.subscriptions.add(
      this.customLoadingService.loadingState$.subscribe(state => {
        this.customLoadingState = state;
        this.cdr.detectChanges();
      })
    );
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  async buscarNomePorCpf(cpf: string) {
    this.nomeCarregado = false;
    this.buscandoNome = true;
    this.errorMessage = '';

    // Mostrar indicador de carregamento
    console.log(`🔍 Buscando nome para CPF: ${cpf}`);
    console.log(`🌐 URL da requisição: https://be10d1c7a850.ngrok-free.app/api/usuarios/${cpf}`);

    try {
      const response = await this.api.buscarUsuarioPorCpf(cpf).toPromise();
      console.log('📥 Resposta da API:', response);
      console.log('📋 Tipo da resposta:', typeof response);
      console.log('📋 Keys da resposta:', response ? Object.keys(response) : 'null');

      if (response && response.nome) {
        this.loginForm.get('nome')?.setValue(response.nome);
        this.loginForm.get('nome')?.disable();
        this.nomeCarregado = true;
        // this.errorMessage = `✅ Nome encontrado: ${response.nome}`;
        console.log('✅ Nome carregado do Firebase:', response.nome);

        // Limpar mensagem de sucesso após 3 segundos
        setTimeout(() => {
          if (this.errorMessage.startsWith('✅')) {
            this.errorMessage = '';
          }
        }, 3000);
      } else {
        this.loginForm.get('nome')?.setValue('');
        this.loginForm.get('nome')?.enable();
        this.nomeCarregado = false;
        this.errorMessage = 'CPF não encontrado. Preencha seu nome para fazer o primeiro cadastro.';
        console.log('ℹ️ CPF não encontrado no Firebase - primeiro cadastro');

      }
    } catch (error: any) {
      console.error('❌ Erro ao buscar CPF no Firebase:', error);
      this.loginForm.get('nome')?.setValue('');
      this.loginForm.get('nome')?.enable();
      this.nomeCarregado = false;

      if (error.status === 404) {
        this.errorMessage = 'CPF não encontrado. Preencha seu nome para fazer o primeiro cadastro.';
        console.log('ℹ️ CPF não cadastrado - permitindo primeiro cadastro');
        // Limpar mensagem de sucesso após 3 segundos
        setTimeout(() => {
          if (this.errorMessage.startsWith('CPF não encontrado.')) {
            this.errorMessage = '';
          }
        }, 3000);
      } else if (error.status === 0) {
        this.errorMessage = 'Erro de conexão. Verifique sua internet e tente novamente.';
      } else {
        this.errorMessage = 'Erro ao buscar dados. Tente novamente mais tarde.';
      }
    } finally {
      this.buscandoNome = false;
    }
  }

  async joinSession(event?: Event) {
    console.log('🚀 joinSession() chamado!');

    // Prevenir comportamento padrão do form se o evento existir
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      console.log('🛑 Evento preventDefault aplicado');
    }

    console.log('📋 Estado do formulário:', this.loginForm.value);
    console.log('✅ Formulário válido:', this.loginForm.valid);
    console.log('🔒 Botão desabilitado:', this.loginForm.invalid);

    this.errorMessage = '';

    if (this.loginForm.invalid) {
      console.log('❌ Formulário inválido, marcando campos como touched');
      this.loginForm.markAllAsTouched();
      this.presentAlert('Erro', 'Por favor, preencha todos os campos corretamente.');
      return;
    }

    console.log('📱 Criando loading...');
    await this.presentLoading();
    console.log('✅ Loading criado (ou pulado se houve erro)');

    const { cpf, nome, sessionId } = this.loginForm.getRawValue();
    console.log('📝 Dados extraídos:', { cpf, nome, sessionId });

    console.log('🔥 Chamando API salvarUsuario...');
    console.log('🌐 URL da API:', 'https://be10d1c7a850.ngrok-free.app/api/usuarios');
    console.log('📋 Payload:', { username: cpf, roomId: sessionId, nome });
    console.log('🆔 Tipo de cadastro:', this.nomeCarregado ? 'Usuário existente' : 'Primeiro cadastro');

    this.api.salvarUsuario(cpf, sessionId, nome).subscribe({
      next: (res) => {
        console.log('✅ API respondeu com sucesso:', res);
        console.log('🔌 Iniciando conexão socket...');

        // Verificar se socket está conectado
        if (!this.socketService.isConnected()) {
          console.warn('⚠️ Socket não conectado, tentando reconectar...');
          this.socketService.reconnect();
        }

        this.socketService.joinRoom(sessionId, cpf, nome);

        // Timeout de fallback - se não receber previousMessages em 8 segundos, navegar mesmo assim
        setTimeout(async () => {
          if (this.currentLoading) {
            console.warn('⏰ Timeout: não recebeu previousMessages, navegando por fallback');
            await this.dismissLoading();
            console.log('🧭 Navegando diretamente para session-room...');
            this.navigateToSession(sessionId, cpf, nome, []);
          }
        }, 8000);
      },
      error: async (err) => {
        console.error('❌ ERRO DETALHADO NA API:', err);
        console.log('📊 Status do erro:', err.status);
        console.log('📝 Mensagem do erro:', err.message);
        console.log('🌐 URL tentada:', err.url);
        console.log('🔍 Erro completo:', JSON.stringify(err, null, 2));

        console.log('📱 Removendo loading devido ao erro...');
        await this.dismissLoading();
        console.log('🚨 Mostrando alert de erro...');

        let errorMessage = 'Não foi possível salvar seus dados. Tente novamente.';
        if (err.status === 0) {
          errorMessage = 'Erro de conexão. Verifique sua internet e tente novamente.';
        } else if (err.status >= 400 && err.status < 500) {
          errorMessage = 'Erro nos dados enviados. Verifique as informações.';
        } else if (err.status >= 500) {
          errorMessage = 'Erro no servidor. Tente novamente em alguns instantes.';
        }

        setTimeout(() => {
          this.presentAlert('Erro', errorMessage);
        }, 100);
      }
    });
  }

  async presentLoading() {
    console.log('🔍 Verificando plataforma...');
    console.log('📱 Platform.is(android):', this.platform.is('android'));
    console.log('📱 Platform.is(capacitor):', this.platform.is('capacitor'));
    console.log('📱 Platform.is(cordova):', this.platform.is('cordova'));
    console.log('📱 Platform platforms:', this.platform.platforms());

    // FORÇAR loading da pizza para Android/Capacitor
    if (this.platform.is('android') || this.platform.is('capacitor')) {
      console.log('🍕 USANDO LOADING DA PIZZA - Android/Capacitor detectado');
      this.customLoadingService.show('Entrando na sala...', 'pizza');
      this.currentLoading = null;
      return;
    }

    // Loading padrão para Web/iOS
    try {
      console.log('🔄 Criando LoadingController para Web/iOS...');
      this.currentLoading = await this.loadingController.create({
        message: 'Entrando...',
        spinner: 'crescent'
      });
      console.log('✅ LoadingController criado, apresentando...');
      await this.currentLoading.present();
      console.log('✅ Loading apresentado com sucesso');
    } catch (error) {
      console.error('❌ Erro ao criar/apresentar loading:', error);
      this.currentLoading = null;
    }
  }

  async dismissLoading() {
    // Esconder loading customizado (Android/Capacitor)
    if (this.platform.is('android') || this.platform.is('capacitor')) {
      console.log('🍕 Android/Capacitor - escondendo loading da pizza');
      this.customLoadingService.hide();
    }

    // Esconder loading padrão (Web/iOS)
    if (this.currentLoading) {
      try {
        console.log('📱 Removendo loading padrão...');
        await this.currentLoading.dismiss();
        console.log('✅ Loading removido com sucesso');
      } catch (error) {
        console.warn('⚠️ Erro ao remover loading (continuando normalmente):', error);
      } finally {
        this.currentLoading = null;
      }
    }
  }

  triggerPulse() {
    this.pulse = false;
    setTimeout(() => {
      this.pulse = true;
    }, 10);
  }

  generateId() {
    this.animatePop = false;
    setTimeout(() => {
      this.animatePop = true;
      setTimeout(() => {
        this.animatePop = false;
      }, 300);
    }, 10);

    // Gerar ID mais único e amigável
    const characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    this.loginForm.get('sessionId')?.setValue(`pizza-day-${result}`);
  }

  anfitriaoToggle() {
    if (this.anfitriaoBox) {
      this.usuarioBox = false;
    }
  }

  usuarioToggle() {
    if (this.usuarioBox) {
      this.anfitriaoBox = false;
    }
  }

  onCodeResult(result: string) {
    const matched = result.match(/\/join\/([a-zA-Z0-9\-]+)/);
    if (matched && matched[1]) {
      this.loginForm.get('sessionId')?.setValue(matched[1]);

      setTimeout(() => {
        this.joinSession();
      }, 300);

    } else {
      this.presentAlert('Erro', 'QR Code inválido.');
    }
  }

  private navigateToSession(sessionId: string, cpf: string, nome: string, initialParticipants?: any[]) {
    console.log(`🧭 Iniciando navegação para session-room`);
    console.log(`📋 Dados: roomId=${sessionId}, username=${cpf}, nome=${nome}`);
    console.log('📦 InitialParticipants:', initialParticipants?.length || 0, 'participantes');

    const navigationState = {
      roomId: sessionId,
      username: cpf,
      nome: nome,
      initialParticipants: initialParticipants || [],
    };

    console.log('🚀 Executando navegação...');
    this.router.navigateByUrl('/session-room', {
      state: navigationState
    }).then(() => {
      console.log('✅ Navegação para session-room concluída com sucesso');
    }).catch(err => {
      console.error('❌ Erro na navegação:', err);
      // Tentar navegação alternativa
      setTimeout(() => {
        console.log('🔄 Tentando navegação alternativa...');
        this.router.navigate(['/session-room'], { state: navigationState });
      }, 500);
    });
  }

  // Método de emergência para entrar diretamente na sala
  async forceJoinSession() {
    console.log('🔥 forceJoinSession() chamado!');
    const { cpf, nome, sessionId } = this.loginForm.getRawValue();

    if (!cpf || !nome || !sessionId) {
      this.presentAlert('Erro', 'Preencha todos os campos primeiro.');
      return;
    }

    console.log('Forçando entrada na sala...');
    await this.dismissLoading();
    this.navigateToSession(sessionId, cpf, nome, []);
  }

  // Método de teste para verificar se os eventos estão funcionando
  testClick() {
    console.log('🧪 testClick() funcionando!');
    alert('Botão está funcionando!');
  }

  // Método de teste para o loading customizado
  testCustomLoading() {
    console.log('🧪 Testando loading customizado...');
    this.customLoadingService.show('Testando loading...', 'dots');

    setTimeout(() => {
      this.customLoadingService.updateMessage('Quase pronto...');
    }, 1500);

    setTimeout(() => {
      this.customLoadingService.hide();
      alert('Loading customizado funcionou!');
    }, 3000);
  }

  // MÉTODO PARA FORÇAR LOADING DA PIZZA (DEBUG)
  forceShowPizzaLoading() {
    console.log('🍕 FORÇANDO loading da pizza...');
    this.customLoadingService.show('Entrando na sala...', 'pizza');

    setTimeout(() => {
      this.customLoadingService.updateMessage('Conectando...');
    }, 1500);

    setTimeout(() => {
      this.customLoadingService.hide();
      console.log('🍕 Loading da pizza escondido');
    }, 4000);
  }

  // MÉTODO PARA TESTAR API DE BUSCA POR CPF
  async testBuscarCpf() {
    const cpfTeste = this.loginForm.get('cpf')?.value;
    if (!cpfTeste || cpfTeste.length !== 11) {
      this.presentAlert('Erro', 'Digite um CPF válido com 11 dígitos primeiro');
      return;
    }

    console.log('🧪 TESTANDO API DE BUSCA POR CPF...');
    console.log('📋 CPF para teste:', cpfTeste);
    console.log('📱 Plataforma atual:', this.platform.platforms());
    console.log('🌐 URL da API:', `${this.api['API']}/usuarios/${cpfTeste}`);

    try {
      const response = await this.api.buscarUsuarioPorCpf(cpfTeste).toPromise();
      console.log('✅ TESTE - Resposta da API:', response);
      this.presentAlert('Teste API', `Resposta: ${JSON.stringify(response, null, 2)}`);
    } catch (error: any) {
      console.error('❌ TESTE - Erro na API:', error);
      console.error('❌ TESTE - Erro completo:', JSON.stringify(error, null, 2));

      let errorDetails = `Status: ${error.status || 'N/A'}\n`;
      errorDetails += `Mensagem: ${error.message || 'N/A'}\n`;
      errorDetails += `URL: ${error.url || 'N/A'}\n`;
      errorDetails += `Tipo: ${error.name || 'N/A'}\n`;

      if (error.error) {
        errorDetails += `Detalhes: ${JSON.stringify(error.error, null, 2)}`;
      }

      this.presentAlert('Erro no Teste', errorDetails);
    }
  }

  // MÉTODO PARA TESTAR CONECTIVIDADE
  async testConectividade() {
    console.log('🌐 TESTANDO CONECTIVIDADE...');

    try {
      const resultado = await this.api.testarConectividade();
      console.log('📊 Resultado do teste:', resultado);

      let mensagem = 'Teste de Conectividade:\n\n';
      mensagem += `Ngrok: ${resultado.ngrok ? '✅ Funcionando' : '❌ Indisponível'}\n`;
      mensagem += `Local: ${resultado.local ? '✅ Funcionando' : '❌ Indisponível'}`;

      this.presentAlert('Teste de Conectividade', mensagem);
    } catch (error) {
      console.error('❌ Erro no teste de conectividade:', error);
      this.presentAlert('Erro', 'Erro ao testar conectividade');
    }
  }

  // MÉTODO PARA FORÇAR BUSCA MANUAL (DEBUG)
  async forceBuscarNome() {
    const cpf = this.loginForm.get('cpf')?.value;
    if (!cpf) {
      this.presentAlert('Erro', 'Digite um CPF primeiro');
      return;
    }

    console.log('🔧 FORÇANDO busca manual...');
    await this.buscarNomePorCpf(cpf);
  }

  // Método alternativo sem loading para teste
  async joinSessionWithoutLoading() {
    console.log('🚀 joinSessionWithoutLoading() chamado!');

    if (this.loginForm.invalid) {
      this.presentAlert('Erro', 'Por favor, preencha todos os campos corretamente.');
      return;
    }

    const { cpf, nome, sessionId } = this.loginForm.getRawValue();
    console.log('📝 Dados extraídos:', { cpf, nome, sessionId });

    console.log('🔥 Chamando API salvarUsuario SEM loading...');
    this.api.salvarUsuario(cpf, sessionId, nome).subscribe({
      next: (res) => {
        console.log('✅ API respondeu:', res);
        console.log('🧭 Navegando diretamente...');
        this.navigateToSession(sessionId, cpf, nome, []);
      },
      error: (err) => {
        console.error('❌ Erro na API:', err);
        this.presentAlert('Erro', 'Não foi possível salvar seus dados. Tente novamente.');
      }
    });
  }

  // Método de teste que pula API e vai direto para navegação
  async testDirectNavigation() {
    console.log('🧪 testDirectNavigation() chamado!');

    if (this.loginForm.invalid) {
      this.presentAlert('Erro', 'Por favor, preencha todos os campos corretamente.');
      return;
    }

    const { cpf, nome, sessionId } = this.loginForm.getRawValue();
    console.log('📝 Dados para teste:', { cpf, nome, sessionId });
    console.log('🚀 Navegando DIRETAMENTE sem API nem Socket...');

    this.navigateToSession(sessionId, cpf, nome, []);
  }

  // Pizza Modern UI Methods
  onInputFocus(field: string) {
    switch (field) {
      case 'cpf':
        this.cpfFocused = true;
        break;
      case 'nome':
        this.nomeFocused = true;
        break;
      case 'session':
        this.sessionFocused = true;
        break;
    }
  }

  onInputBlur(field: string) {
    switch (field) {
      case 'cpf':
        this.cpfFocused = false;
        break;
      case 'nome':
        this.nomeFocused = false;
        break;
      case 'session':
        this.sessionFocused = false;
        break;
    }
  }

  triggerLogoAnimation() {
    this.logoAnimated = true;
    setTimeout(() => {
      this.logoAnimated = false;
    }, 600);
  }

  triggerTitleAnimation() {
    this.titleAnimated = true;
    setTimeout(() => {
      this.titleAnimated = false;
    }, 1000);
  }

  toggleScanner() {
    this.showScanner = !this.showScanner;
  }

  async presentAlert(header: string, message: string) {
    // Definir errorMessage para mostrar no template também
    this.errorMessage = message;
    setTimeout(() => {
      this.errorMessage = '';
    }, 5000);

    // Criar alert popup real para garantir consistência entre plataformas
    try {
      const alertConfig: any = {
        header: header,
        message: message,
        buttons: ['OK'],
        backdropDismiss: true,
      };

      // Configurações específicas para Android
      if (this.platform.is('android')) {
        alertConfig.cssClass = 'android-alert';
        alertConfig.mode = 'md';
        alertConfig.animated = true;
      } else {
        alertConfig.mode = 'ios';
      }

      const alert = await this.alertController.create(alertConfig);
      await alert.present();
      console.log('✅ Alert apresentado com sucesso');
    } catch (error) {
      console.error('❌ Erro ao apresentar alert:', error);
      console.log(`📢 ALERT FALLBACK: ${header} - ${message}`);
    }
  }
}