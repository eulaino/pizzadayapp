import { Component, OnInit, OnDestroy, ChangeDetectorRef, AfterViewInit, NgZone } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SocketService, Participant } from '../services/socket.service';
import { AlertController, NavController } from '@ionic/angular';
import { Subscription } from 'rxjs';

import { ZXingScannerModule } from '@zxing/ngx-scanner';
import { QRCodeComponent } from 'angularx-qrcode';
import { BarcodeFormat } from '@zxing/library';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonButton,
  IonIcon,
  IonGrid,
  IonRow,
  IonCol,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonText,
  IonList,
  IonItem,
  IonLabel,
  IonSelect,
  IonSelectOption
} from '@ionic/angular/standalone';

interface Pizza {
  sabor: string;
  fatias: number;
  valor: number;
}

interface UserSliceData {
  [pizzaIndex: number]: number; // número de fatias por pizza
}

interface GlobalSliceData {
  [pizzaIndex: number]: {
    [username: string]: number; // fatias por usuário por pizza
  };
}

@Component({
  selector: 'app-session-room',
  templateUrl: './session-room.page.html',
  styleUrls: ['./session-room.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    QRCodeComponent,
    ZXingScannerModule,
    IonTitle,
    IonContent,
    IonButtons,
    IonButton,
    IonIcon,
    IonGrid,
    IonRow,
    IonCol,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonText,
    IonList,
    IonItem,
    IonLabel,
    IonSelect,
    IonSelectOption
  ]
})
export class SessionRoomPage implements OnInit, OnDestroy, AfterViewInit {
  roomId: string = '';
  cpf: string = '';
  nome: string = '';
  pizzaSlices: number = 0;
  isHost: boolean = false;
  participants: Participant[] = [];
  barcodeFormats = [BarcodeFormat.QR_CODE];
  selectedParticipantToRemove: string = '';
  pulse = false;
  animatePop = false;
  private isInitialized = false;

  // NOVO: Sistema de gerenciamento de pizzas
  pizzasList: Pizza[] = [];
  newPizza: Pizza = {
    sabor: '',
    fatias: 8,
    valor: 0
  };
  userSliceData: UserSliceData = {}; // fatias do usuário atual por pizza
  globalSliceData: GlobalSliceData = {}; // controle global de todas as fatias

  // Configurações da sala
  roomSettings: any = {
    divisionType: 'consumption', // 'consumption' ou 'equal'
    showQRCode: true,
    pizzas: [],
    globalSlices: {}
  };

  // UI Estado
  showPizzaPanel: boolean = false;
  settingsChanged: boolean = false;
  settingsUpdateMessage: string = '';
  isSyncing: boolean = false;
  lastSyncTime: Date = new Date();
  autoSyncInterval: any;
  private originalSettings: any = {};

  triggerPulse() {
    this.pulse = false;
    setTimeout(() => {
      this.pulse = true;
    }, 10);
  }

  private subscriptions: Subscription = new Subscription();

  constructor(
    private router: Router,
    private socketService: SocketService,
    private alertController: AlertController,
    private navCtrl: NavController,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras.state) {
      this.roomId = navigation.extras.state['roomId'];
      this.cpf = navigation.extras.state['username'];
      this.nome = navigation.extras.state['nome'];
      this.participants = navigation.extras.state['initialParticipants'] || [];

      if (navigation.extras.state['roomSettings']) {
        this.roomSettings = navigation.extras.state['roomSettings'];
        this.originalSettings = { ...this.roomSettings };
        this.pizzasList = this.roomSettings.pizzas || [];
        this.globalSliceData = this.roomSettings.globalSlices || {};
      }

      const currentUserData = this.participants.find(p => p.author === this.nome);
      if (currentUserData) {
        this.pizzaSlices = currentUserData.pizza;
        this.isHost = currentUserData.isHost || false;
      }
    }
  }

  ngOnInit() {
    if (!this.roomId || !this.cpf || !this.nome) {
      this.navCtrl.navigateRoot('/home');
      return;
    }

    console.log('🚀 Inicializando sistema de pizzas:', {
      roomId: this.roomId,
      nome: this.nome,
      isHost: this.isHost
    });

    this.setupSocketListeners();
    this.loadRoomSettings();
    this.initializeSession();

    // Se já é host, mostrar painel
    if (this.isHost) {
      this.showPizzaPanel = true;
    }



    // Iniciar sincronização automática
    this.startAutoSync();
    
    // Configurar detecção de visibilidade
    this.setupVisibilityDetection();
  }

  // Iniciar sincronização automática em intervalos regulares
  private startAutoSync() {
    // Sincronizar a cada 5 segundos (como backup)
    this.autoSyncInterval = setInterval(() => {
      if (this.roomId && this.nome) {
        // Só sincronizar se houve atividade recente (últimos 30 segundos)
        const timeSinceLastSync = Date.now() - this.lastSyncTime.getTime();
        const hasRecentActivity = timeSinceLastSync < 30000; // 30 segundos
        
        if (hasRecentActivity || Object.keys(this.globalSliceData).length > 0) {
          this.autoSyncData();
        }
      }
    }, 5000);

    console.log('🔄 Sincronização automática iniciada (intervalo: 5s)');
  }

  // Método de sincronização automática silenciosa
  private autoSyncData() {
    // Não mostrar indicador de sincronização para auto-sync
    const wasManualSync = this.isSyncing;
    
    if (!wasManualSync) {
      // Verificar se há dados para sincronizar
      const hasSliceData = Object.keys(this.globalSliceData).length > 0;
      const hasUserData = Object.keys(this.userSliceData).length > 0;
      
      if (hasSliceData || hasUserData) {
        this.lastSyncTime = new Date();
        this.roomSettings.globalSlices = this.globalSliceData;
        
        // Enviar dados silenciosamente
        this.socketService.emit('updateGlobalSlices', {
          roomId: this.roomId,
          globalSlices: this.globalSliceData,
          updatedBy: this.nome,
          timestamp: Date.now(),
          autoSync: true // Flag para indicar sync automático
        });
        
        console.log('🔄 Auto-sync executado:', {
          globalSlices: Object.keys(this.globalSliceData).length,
          userSlices: Object.keys(this.userSliceData).length,
          totalParticipants: this.participants.length
        });
      }
    }
  }

  // NOVO: Métodos de controle global de fatias
  getAvailableSlices(pizzaIndex: number): number {
    const pizza = this.pizzasList[pizzaIndex];
    if (!pizza) return 0;
    
    const consumedSlices = this.getConsumedSlices(pizzaIndex);
    return Math.max(0, pizza.fatias - consumedSlices);
  }

  getConsumedSlices(pizzaIndex: number): number {
    if (!this.globalSliceData[pizzaIndex]) return 0;
    
    return Object.values(this.globalSliceData[pizzaIndex]).reduce((sum, slices) => sum + slices, 0);
  }

  getTotalAvailableSlices(): number {
    return this.pizzasList.reduce((sum, pizza, index) => sum + this.getAvailableSlices(index), 0);
  }

  getUserTotalSlicesForParticipant(username: string): number {
    let total = 0;
    for (const pizzaIndex in this.globalSliceData) {
      if (this.globalSliceData[pizzaIndex][username]) {
        total += this.globalSliceData[pizzaIndex][username];
      }
    }
    return total;
  }

  // NOVO: Métodos de gerenciamento de pizzas
  togglePizzaPanel() {
    this.showPizzaPanel = !this.showPizzaPanel;
  }

  addPizza() {
    if (!this.newPizza.sabor || !this.newPizza.fatias || !this.newPizza.valor) {
      this.presentAlert('Erro', 'Preencha todos os campos da pizza.');
      return;
    }

    this.pizzasList.push({ ...this.newPizza });
    
    // Resetar formulário
    this.newPizza = {
      sabor: '',
      fatias: 8,
      valor: 0
    };

    this.updateRoomSettings();
    this.onSettingsChange();
    
    // Sincronizar imediatamente
    this.syncGlobalSliceData();
    
    console.log('🍕 Pizza adicionada e sincronizada:', this.pizzasList);
  }

  removePizza(index: number) {
    const pizzaName = this.pizzasList[index]?.sabor || 'Pizza';
    
    this.pizzasList.splice(index, 1);
    
    // Remover fatias globais desta pizza
    if (this.globalSliceData[index]) {
      delete this.globalSliceData[index];
    }
    
    // Remover fatias do usuário desta pizza
    if (this.userSliceData[index] !== undefined) {
      delete this.userSliceData[index];
    }

    // Reorganizar índices das pizzas restantes
    this.reorganizeSliceData(index);
    
    this.updateRoomSettings();
    this.onSettingsChange();
    
    // Atualizar total de fatias do usuário
    this.updateUserTotalSlices();
    
    // Sincronizar com todos
    this.syncGlobalSliceData();
    
    console.log('🗑️ Pizza removida e sincronizada:', pizzaName);
  }

  private reorganizeSliceData(removedIndex: number) {
    // Reorganizar globalSliceData
    const newGlobalSliceData: GlobalSliceData = {};
    for (const pizzaIndex in this.globalSliceData) {
      const index = parseInt(pizzaIndex);
      if (index < removedIndex) {
        newGlobalSliceData[index] = this.globalSliceData[index];
      } else if (index > removedIndex) {
        newGlobalSliceData[index - 1] = this.globalSliceData[index];
      }
    }
    this.globalSliceData = newGlobalSliceData;

    // Reorganizar userSliceData
    const newUserSliceData: UserSliceData = {};
    for (const pizzaIndex in this.userSliceData) {
      const index = parseInt(pizzaIndex);
      if (index < removedIndex) {
        newUserSliceData[index] = this.userSliceData[index];
      } else if (index > removedIndex) {
        newUserSliceData[index - 1] = this.userSliceData[index];
      }
    }
    this.userSliceData = newUserSliceData;
  }

  addSliceToPizza(pizzaIndex: number) {
    const pizza = this.pizzasList[pizzaIndex];
    if (!pizza) return;

    const availableSlices = this.getAvailableSlices(pizzaIndex);
    if (availableSlices <= 0) {
      this.presentAlert('Esgotado', `Não há mais fatias disponíveis desta pizza.`);
      return;
    }

    // Atualizar fatias do usuário
    if (!this.userSliceData[pizzaIndex]) {
      this.userSliceData[pizzaIndex] = 0;
    }
    this.userSliceData[pizzaIndex]++;

    // Atualizar fatias globais
    if (!this.globalSliceData[pizzaIndex]) {
      this.globalSliceData[pizzaIndex] = {};
    }
    if (!this.globalSliceData[pizzaIndex][this.nome]) {
      this.globalSliceData[pizzaIndex][this.nome] = 0;
    }
    this.globalSliceData[pizzaIndex][this.nome]++;

    // Sincronizar apenas dados de fatias (não configurações da sala)
    this.syncSliceDataOnly();
    this.updateUserTotalSlices();
    this.triggerPulse();
    
    console.log('✅ Fatia adicionada:', {
      pizza: pizza.sabor,
      usuario: this.nome,
      fatias: this.userSliceData[pizzaIndex],
      globalData: this.globalSliceData[pizzaIndex]
    });
  }

  removeSliceFromPizza(pizzaIndex: number) {
    if (!this.userSliceData[pizzaIndex] || this.userSliceData[pizzaIndex] <= 0) {
      this.presentAlert('Ops!', 'Você não tem fatias desta pizza para remover.');
      return;
    }

    // Atualizar fatias do usuário
    this.userSliceData[pizzaIndex]--;
    if (this.userSliceData[pizzaIndex] <= 0) {
      delete this.userSliceData[pizzaIndex];
    }

    // Atualizar fatias globais
    if (this.globalSliceData[pizzaIndex] && this.globalSliceData[pizzaIndex][this.nome]) {
      this.globalSliceData[pizzaIndex][this.nome]--;
      if (this.globalSliceData[pizzaIndex][this.nome] <= 0) {
        delete this.globalSliceData[pizzaIndex][this.nome];
        if (Object.keys(this.globalSliceData[pizzaIndex]).length === 0) {
          delete this.globalSliceData[pizzaIndex];
        }
      }
    }

    // Sincronizar apenas dados de fatias (não configurações da sala)
    this.syncSliceDataOnly();
    this.updateUserTotalSlices();
    this.triggerPulse();
    
    console.log('✅ Fatia removida:', {
      pizza: this.pizzasList[pizzaIndex]?.sabor,
      usuario: this.nome,
      fatias: this.userSliceData[pizzaIndex] || 0,
      globalData: this.globalSliceData[pizzaIndex]
    });
  }

  private syncGlobalSliceData() {
    this.isSyncing = true;
    
    // Atualizar timestamp
    this.lastSyncTime = new Date();
    
    // Atualizar configurações locais
    this.roomSettings.globalSlices = this.globalSliceData;
    
    // Salvar no servidor (apenas hosts podem fazer isso)
    if (this.isHost) {
      this.saveSettingsToServer().catch(error => {
        console.error('Erro ao salvar configurações:', error);
      }).finally(() => {
        this.isSyncing = false;
        this.cdr.detectChanges();
      });
    } else {
      // Para não-hosts, esconder indicador após um delay menor
      setTimeout(() => {
        this.isSyncing = false;
        this.cdr.detectChanges();
      }, 500);
    }
    
    // Enviar dados globais atualizados via socket para todos os usuários
    this.socketService.emit('updateGlobalSlices', {
      roomId: this.roomId,
      globalSlices: this.globalSliceData,
      settings: this.roomSettings,
      updatedBy: this.nome,
      timestamp: Date.now()
    });
    
    // Enviar atualização de configurações da sala (apenas hosts)
    if (this.isHost) {
      this.socketService.emit('updateRoomSettings', {
        roomId: this.roomId,
        settings: this.roomSettings,
        updatedBy: this.nome
      });
    }
    
    console.log('🔄 Sincronizando dados globais:', {
      globalSlices: this.globalSliceData,
      totalValue: this.getTotalPizzasValue(),
      totalSlices: this.getTotalSlices(),
      timestamp: this.lastSyncTime,
      isHost: this.isHost
    });
  }

  // Método separado para sincronizar apenas fatias (usado por participantes não-host)
  private syncSliceDataOnly() {
    this.isSyncing = true;
    
    // Atualizar timestamp
    this.lastSyncTime = new Date();
    
    // Atualizar configurações locais
    this.roomSettings.globalSlices = this.globalSliceData;
    
    // Enviar apenas dados de fatias via socket (qualquer participante pode fazer)
    this.socketService.emit('updateGlobalSlices', {
      roomId: this.roomId,
      globalSlices: this.globalSliceData,
      updatedBy: this.nome,
      timestamp: Date.now(),
      slicesOnly: true  // Flag para indicar que é apenas atualização de fatias
    });
    
    // Esconder indicador após um delay menor
    setTimeout(() => {
      this.isSyncing = false;
      this.cdr.detectChanges();
    }, 400);
    
    console.log('🔄 Sincronizando apenas fatias:', {
      globalSlices: this.globalSliceData,
      usuario: this.nome,
      timestamp: this.lastSyncTime
    });
  }

  getUserSlicesFromPizza(pizzaIndex: number): number {
    return this.userSliceData[pizzaIndex] || 0;
  }

  getTotalUserSlices(): number {
    return Object.values(this.userSliceData).reduce((sum, slices) => sum + slices, 0);
  }

  updateUserTotalSlices() {
    const newTotal = this.getTotalUserSlices();
    this.pizzaSlices = newTotal;
    
    // Atualizar localmente
    const me = this.participants.find(p => p.author === this.nome);
    if (me) {
      me.pizza = this.pizzaSlices;
    }
    
    // Enviar atualização via socket (mensagem tradicional)
    this.socketService.sendMessage(this.nome, this.pizzaSlices, this.roomId);
    
    console.log('📊 Total de fatias atualizado:', {
      usuario: this.nome,
      totalFatias: this.pizzaSlices,
      detalhePorPizza: this.userSliceData
    });
    
    this.cdr.detectChanges();
  }

  updateRoomSettings() {
    this.roomSettings.pizzas = this.pizzasList;
    this.roomSettings.globalSlices = this.globalSliceData;
  }

  // Reset de fatias (apenas para host)
  resetAllSlices() {
    if (!this.isHost) return;

    this.globalSliceData = {};
    this.userSliceData = {};
    
    // Reset de todos os participantes
    this.participants.forEach(p => {
      p.pizza = 0;
    });

    this.pizzaSlices = 0;
    this.updateRoomSettings();
    
    // Sincronizar com todos (método completo para hosts)
    this.syncGlobalSliceData();
    
    // Forçar atualização via socket tradicional também
    this.socketService.sendMessage(this.nome, 0, this.roomId);

    this.presentAlert('Reset Completo', 'Todas as fatias foram resetadas para todos os participantes.');
    
    console.log('🔄 Reset completo executado pelo host');
  }

  // Método auxiliar para debug
  checkDataConsistency(): boolean {
    const myCalculatedSlices = this.getTotalUserSlices();
    const myGlobalSlices = this.getUserTotalSlicesForParticipant(this.nome);
    return myCalculatedSlices === myGlobalSlices;
  }

  // Verificar se é host ou pode executar ações
  canExecuteAdminActions(): boolean {
    return this.isHost;
  }

  // Método para apresentar alertas com contexto melhor
  async presentContextAlert(header: string, message: string, isError: boolean = false) {
    const contextMessage = isError ? 
      `${message}\n\nVocê é um ${this.isHost ? 'HOST' : 'PARTICIPANTE'} da sessão.` : 
      message;
    
    await this.presentAlert(header, contextMessage);
  }

  // Detectar quando usuário volta à aba (para sincronizar)
  private setupVisibilityDetection() {
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && this.roomId) {
        // Usuário voltou à aba, sincronizar dados
        console.log('👁️ Usuário voltou à aba, sincronizando...');
        this.autoSyncData();
      }
    });
  }

  // Métodos de cálculo
  getTotalPizzasValue(): number {
    return this.pizzasList.reduce((sum, pizza) => sum + pizza.valor, 0);
  }

  getTotalSlices(): number {
    return this.pizzasList.reduce((sum, pizza) => sum + pizza.fatias, 0);
  }

  getMyShare(): number {
    if (this.roomSettings.divisionType === 'equal') {
      return this.getEqualShare();
    } else {
      return this.getConsumptionShare();
    }
  }

  getEqualShare(): number {
    const totalValue = this.getTotalPizzasValue();
    return this.participants.length > 0 ? totalValue / this.participants.length : 0;
  }

  getConsumptionShare(): number {
    let total = 0;
    
    for (const pizzaIndex in this.userSliceData) {
      const pizza = this.pizzasList[parseInt(pizzaIndex)];
      if (pizza) {
        const sliceValue = pizza.valor / pizza.fatias;
        const userSlices = this.userSliceData[parseInt(pizzaIndex)];
        total += sliceValue * userSlices;
      }
    }
    
    return total;
  }

  getFormattedShare(): string {
    const valor = this.getMyShare();
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }

  // Configurações
  changeDivisionType(type: 'consumption' | 'equal') {
    this.roomSettings.divisionType = type;
    this.onSettingsChange();
  }

  onSettingsChange() {
    this.settingsChanged = this.hasSettingsChanged();
  }

  private hasSettingsChanged(): boolean {
    return JSON.stringify(this.roomSettings) !== JSON.stringify(this.originalSettings);
  }

  async saveSettings() {
    if (!this.isHost) {
      this.presentAlert('Acesso Restrito', 'Apenas hosts podem alterar configurações da sala. Você pode pegar/devolver fatias normalmente.');
      return;
    }

    if (!this.settingsChanged) {
      return;
    }

    try {
      await this.saveSettingsToServer();
      
      // Notificar outros usuários via socket
      this.socketService.emit('updateRoomSettings', {
        roomId: this.roomId,
        settings: this.roomSettings,
        updatedBy: this.nome
      });

      this.originalSettings = { ...this.roomSettings };
      this.settingsChanged = false;
      this.showSettingsUpdateMessage('Configurações salvas com sucesso!');
      
    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
      this.presentAlert('Erro', 'Não foi possível salvar as configurações.');
    }
  }

  private async saveSettingsToServer(settings?: any): Promise<void> {
    const settingsToSave = settings || this.roomSettings;
    
    const response = await fetch('https://87138696a2ea.ngrok-free.app/api/room-settings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...settingsToSave,
        roomId: this.roomId,
        createdBy: this.cpf,
        createdAt: Date.now()
      })
    });

    if (!response.ok) {
      throw new Error('Erro ao salvar configurações');
    }
    
    console.log('💾 Configurações salvas no servidor');
  }

  private showSettingsUpdateMessage(message: string) {
    this.settingsUpdateMessage = message;
    setTimeout(() => {
      this.settingsUpdateMessage = '';
      this.cdr.detectChanges();
    }, 3000);
  }

  // Socket listeners e outros métodos existentes...
  private setupSocketListeners() {
    this.subscriptions.add(
      this.socketService.onReceivedMessage().subscribe((message: Participant) => {
        this.ngZone.run(() => {
          if (message.roomId === this.roomId) {
            this.updateParticipantList(message);
            if (message.author === this.nome) {
              this.pizzaSlices = message.pizza;
              if (message.isHost !== undefined) {
                this.isHost = message.isHost;
              }
            }
          }
        });
      })
    );

    this.subscriptions.add(
      this.socketService.onYouAreHost().subscribe((data) => {
        this.ngZone.run(() => {
          this.isHost = data.isHost;
          this.updateHostSelectAndButtons();
          this.isInitialized = true;
          console.log('🏠 Host status atualizado:', this.isHost);
          if (this.isHost) {
            this.showPizzaPanel = true;
            this.forceLoadSettings();
          }
        });
      })
    );

    this.subscriptions.add(
      this.socketService.onRoomJoined().subscribe((data) => {
        this.ngZone.run(() => {
          if (data.roomId === this.roomId) {
            this.participants = data.participants || [];
            const currentUser = this.participants.find(p => p.author === this.nome);
            if (currentUser) {
              this.isHost = currentUser.isHost || false;
              this.pizzaSlices = currentUser.pizza || 0;
            }
            if (data.isHost !== undefined) {
              this.isHost = data.isHost;
            }
            this.isInitialized = true;
            console.log('🏠 Sessão inicializada. isHost:', this.isHost);
            if (this.isHost) {
              this.showPizzaPanel = true;
              setTimeout(() => this.forceLoadSettings(), 1000);
            }
            this.cdr.detectChanges();
          }
        });
      })
    );

    // Listener para mudanças de configurações
    this.subscriptions.add(
      this.socketService.listen('roomSettingsUpdated').subscribe((data: any) => {
        this.ngZone.run(() => {
          if (data.roomId === this.roomId) {
            this.roomSettings = data.settings;
            this.originalSettings = { ...data.settings };
            this.pizzasList = data.settings.pizzas || [];
            this.globalSliceData = data.settings.globalSlices || {};
            this.settingsChanged = false;
            this.showSettingsUpdateMessage(`Configurações atualizadas por ${data.updatedBy}`);
            console.log('🔧 Configurações atualizadas via socket:', this.roomSettings);
            this.cdr.detectChanges();
          }
        });
      })
    );

    // NOVO: Listener para sincronização de fatias globais
    this.subscriptions.add(
      this.socketService.listen('globalSlicesUpdated').subscribe((data: any) => {
        this.ngZone.run(() => {
          if (data.roomId === this.roomId && data.updatedBy !== this.nome) {
            // Não mostrar logs excessivos para auto-sync
            if (!data.autoSync) {
              console.log('📡 Recebendo atualizações de fatias de:', data.updatedBy);
            }
            
            // Atualizar timestamp
            this.lastSyncTime = new Date();
            
            // Atualizar dados globais sempre
            this.globalSliceData = data.globalSlices;
            this.roomSettings.globalSlices = data.globalSlices;
            
            // Se não é apenas fatias e recebeu settings junto, atualizar também
            if (!data.slicesOnly && !data.autoSync && data.settings) {
              this.roomSettings = data.settings;
              this.pizzasList = data.settings.pizzas || [];
              if (!data.autoSync) {
                console.log('📝 Configurações também atualizadas');
              }
            }
            
            // Recalcular fatias de todos os participantes
            this.participants.forEach(participant => {
              const totalSlices = this.getUserTotalSlicesForParticipant(participant.author);
              participant.pizza = totalSlices;
            });
            
            // Se for o usuário atual, atualizar também os dados locais
            const myTotalSlices = this.getUserTotalSlicesForParticipant(this.nome);
            this.pizzaSlices = myTotalSlices;
            
            if (!data.autoSync) {
              console.log('✅ Interface atualizada com novas fatias:', {
                globalData: this.globalSliceData,
                mySlices: this.pizzaSlices,
                participants: this.participants.map(p => ({ name: p.author, slices: p.pizza })),
                slicesOnly: data.slicesOnly || false
              });
            }
            
            this.cdr.detectChanges();
          }
        });
      })
    );

    // Listener para resposta de configurações
    this.subscriptions.add(
      this.socketService.listen('roomSettingsResponse').subscribe((data: any) => {
        this.ngZone.run(() => {
          console.log('🔧 Configurações recebidas:', data);
          if (data.roomId === this.roomId) {
            this.roomSettings = data.settings;
            this.originalSettings = { ...data.settings };
            this.pizzasList = data.settings.pizzas || [];
            this.globalSliceData = data.settings.globalSlices || {};
            this.settingsChanged = false;
            console.log('✅ Configurações aplicadas:', this.roomSettings);
            this.cdr.detectChanges();
          }
        });
      })
    );

    this.subscriptions.add(
      this.socketService.onUserLeft().subscribe((data) => {
        this.ngZone.run(() => {
          if (data.roomId === this.roomId) {
            this.removeParticipantFromList(data.author);
            this.updateHostSelectAndButtons();
            this.cdr.detectChanges();
          }
        });
      })
    );

    this.subscriptions.add(
      this.socketService.onError().subscribe(async (message) => {
        this.ngZone.run(async () => {
          await this.presentAlert('Erro', message);
        });
      })
    );
  }

  private async loadRoomSettings() {
    console.log('📥 Carregando configurações da sala:', this.roomId);
    try {
      const response = await fetch(`https://87138696a2ea.ngrok-free.app/api/room-settings/${this.roomId}`);
      if (response.ok) {
        const settings = await response.json();
        this.roomSettings = settings;
        this.originalSettings = { ...settings };
        this.pizzasList = settings.pizzas || [];
        this.globalSliceData = settings.globalSlices || {};
        console.log('✅ Configurações carregadas:', settings);
        this.cdr.detectChanges();
      } else if (response.status === 404) {
        console.log('ℹ️ Sala sem configurações personalizadas, usando padrões');
        if (this.isHost) {
          await this.createDefaultSettings();
        }
      }
    } catch (error) {
      console.error('❌ Erro ao carregar configurações da sala:', error);
    }
  }

  async forceLoadSettings() {
    console.log('🔄 Forçando carregamento das configurações...');
    
    this.socketService.emit('getRoomSettings', { roomId: this.roomId });
    
    setTimeout(async () => {
      try {
        const response = await fetch(`https://87138696a2ea.ngrok-free.app/api/room-settings/${this.roomId}`);
        if (response.ok) {
          const settings = await response.json();
          this.roomSettings = settings;
          this.originalSettings = { ...settings };
          this.pizzasList = settings.pizzas || [];
          this.globalSliceData = settings.globalSlices || {};
          console.log('✅ Configurações carregadas via HTTP:', settings);
          this.cdr.detectChanges();
        } else if (response.status === 404 && this.isHost) {
          console.log('ℹ️ Criando configurações padrão...');
          await this.createDefaultSettings();
        }
      } catch (error) {
        console.error('❌ Erro ao carregar configurações:', error);
      }
    }, 1000);
  }

  private async createDefaultSettings() {
    const defaultSettings = {
      divisionType: 'consumption',
      showQRCode: true,
      pizzas: [],
      globalSlices: {}
    };

    try {
      await this.saveSettingsToServer(defaultSettings);
      this.roomSettings = defaultSettings;
      this.originalSettings = { ...defaultSettings };
      this.pizzasList = [];
      this.globalSliceData = {};
      console.log('✅ Configurações padrão criadas:', defaultSettings);
      this.cdr.detectChanges();
    } catch (error) {
      console.error('❌ Erro ao criar configurações padrão:', error);
    }
  }

  private initializeSession() {
    if (this.socketService.currentRoomId === this.roomId && 
        this.socketService.currentUsername === this.cpf) {
      this.requestCurrentStatus();
    } else {
      this.socketService.joinRoom(this.roomId, this.cpf);
    }

    if (this.participants && this.participants.length > 0) {
      const currentUser = this.participants.find(p => p.author === this.nome);
      if (currentUser) {
        this.isHost = currentUser.isHost || false;
        this.pizzaSlices = currentUser.pizza || 0;
        this.isInitialized = true;
        console.log('📊 Status inicial definido:', { isHost: this.isHost, pizzaSlices: this.pizzaSlices });
      }
    }

    setTimeout(() => {
      if (!this.isInitialized) {
        console.log('⏰ Timeout: solicitando status...');
        this.requestCurrentStatus();
      }
      
      if (this.isHost) {
        console.log('👑 É host: carregando configurações...');
        this.forceLoadSettings();
      }
    }, 2000);
  }

  private requestCurrentStatus() {
    this.socketService.requestRoomStatus(this.roomId);
    this.socketService.checkCurrentUserHost(this.roomId);
  }

  ngAfterViewInit() {
    setTimeout(() => {
      if (!this.isInitialized) {
        this.requestCurrentStatus();
      }
    }, 100);
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
    
    // Parar sincronização automática
    if (this.autoSyncInterval) {
      clearInterval(this.autoSyncInterval);
      console.log('🔄 Sincronização automática parada');
    }
  }

  // Métodos auxiliares
  updateParticipantList(newMessage: Participant) {
    const index = this.participants.findIndex(p => p.author === newMessage.author);
    if (index > -1) {
      this.participants[index] = { ...newMessage };
    } else {
      this.participants.push({ ...newMessage });
    }

    if (newMessage.author === this.nome) {
      this.pizzaSlices = newMessage.pizza;
      if (newMessage.isHost !== undefined) {
        this.isHost = newMessage.isHost;
      }
    }

    this.participants.sort((a, b) => {
      if (a.isHost && !b.isHost) return -1;
      if (!a.isHost && b.isHost) return 1;
      return a.author.localeCompare(b.author);
    });

    // Sincronizar automaticamente quando a lista de participantes muda
    setTimeout(() => this.autoSyncData(), 100);

    this.cdr.detectChanges();
  }

  removeParticipantFromList(author: string) {
    this.participants = this.participants.filter(p => p.author !== author);
    
    // Remover fatias do usuário que saiu
    let hasChanges = false;
    for (const pizzaIndex in this.globalSliceData) {
      if (this.globalSliceData[pizzaIndex][author]) {
        delete this.globalSliceData[pizzaIndex][author];
        hasChanges = true;
        if (Object.keys(this.globalSliceData[pizzaIndex]).length === 0) {
          delete this.globalSliceData[pizzaIndex];
        }
      }
    }
    
    // Sincronizar automaticamente se houve mudanças
    if (hasChanges) {
      if (this.isHost) {
        this.syncGlobalSliceData();
      } else {
        this.syncSliceDataOnly();
      }
    }
  }

  hostRemoveSlice() {
    if (!this.isHost) {
      this.presentAlert('Permissão Negada', 'Apenas o host pode remover fatias de outros participantes.');
      return;
    }
    if (!this.selectedParticipantToRemove) {
      this.presentAlert('Erro', 'Selecione um participante para ajustar fatias.');
      return;
    }

    // Encontrar e remover uma fatia do participante selecionado
    let removed = false;
    for (const pizzaIndex in this.globalSliceData) {
      if (this.globalSliceData[pizzaIndex][this.selectedParticipantToRemove] > 0) {
        this.globalSliceData[pizzaIndex][this.selectedParticipantToRemove]--;
        if (this.globalSliceData[pizzaIndex][this.selectedParticipantToRemove] <= 0) {
          delete this.globalSliceData[pizzaIndex][this.selectedParticipantToRemove];
          if (Object.keys(this.globalSliceData[pizzaIndex]).length === 0) {
            delete this.globalSliceData[pizzaIndex];
          }
        }
        removed = true;
        break;
      }
    }

    if (removed) {
      // Usar sincronização completa já que é host
      this.syncGlobalSliceData();
      this.presentAlert('Fatia Removida', `Uma fatia foi removida de ${this.selectedParticipantToRemove}.`);
    } else {
      this.presentAlert('Erro', `${this.selectedParticipantToRemove} não tem fatias para remover.`);
    }

    this.selectedParticipantToRemove = '';
    this.cdr.detectChanges();
  }

  async toggleHostStatus() {
    if (!this.isHost) {
      const alert = await this.alertController.create({
        header: 'Tornar-se Host',
        message: 'Deseja se tornar host desta sessão?',
        buttons: [
          {
            text: 'Cancelar',
            role: 'cancel'
          },
          {
            text: 'Sim',
            handler: async () => {
              try {
                const response = await fetch('https://87138696a2ea.ngrok-free.app/api/set-host', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                  },
                  body: JSON.stringify({
                    cpf: this.cpf,
                    roomId: this.roomId,
                    nome: this.nome
                  })
                });

                if (response.ok) {
                  this.isHost = true;
                  this.showPizzaPanel = true;
                  this.presentAlert('Sucesso', 'Você agora é host desta sessão!');
                  this.requestCurrentStatus();
                } else {
                  this.presentAlert('Erro', 'Não foi possível tornar-se host.');
                }
              } catch (error) {
                console.error('Erro ao definir host:', error);
                this.presentAlert('Erro', 'Erro de conexão.');
              }
            }
          }
        ]
      });
      await alert.present();
    }
  }

  async leaveSession() {
    const alert = await this.alertController.create({
      header: 'Ops!',
      message: 'Tem certeza que deseja sair da sessão?',
      buttons: [
        {
          text: 'NÃO',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Cancelou sair da sessão');
          }
        }, {
          text: 'SIM',
          handler: () => {
            this.socketService.leaveRoom(this.roomId);
            this.socketService.resetSessionState(this.roomId);
            this.navCtrl.navigateRoot('/home');
          }
        }
      ],
    });
    await alert.present();
  }

  updateHostSelectAndButtons() {
    this.selectedParticipantToRemove = '';
    this.cdr.detectChanges();
  }

  async presentAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header: header,
      message: message,
      buttons: ['OK'],
    });
    await alert.present();
  }
}