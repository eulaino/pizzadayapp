import { Component, OnInit, OnDestroy } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { SocketService } from '../services/socket.service';
import { AlertController, NavController, LoadingController, Platform } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { ChangeDetectorRef } from '@angular/core';
import { ZXingScannerModule } from '@zxing/ngx-scanner';
import { QRCodeComponent } from 'angularx-qrcode';
import { BarcodeFormat } from '@zxing/library';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonIcon,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonFooter,
  IonList,
  IonItem,
  IonInput,
  IonButton
} from '@ionic/angular/standalone';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    QRCodeComponent,
    ZXingScannerModule,
    IonHeader,
    IonToolbar,
    IonIcon,
    IonTitle,
    IonContent,
    IonFooter,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonList,
    IonItem,
    IonInput,
    IonButton
  ]
})
export class HomePage implements OnInit, OnDestroy {
  barcodeFormats = [BarcodeFormat.QR_CODE];
  showScanner = false;
  anfitriaoBox = false;
  usuarioBox = false;
  errorMessage: string = '';
  pulse = false;
  animatePop = false;

  private subscriptions: Subscription = new Subscription();
  private currentLoading: HTMLIonLoadingElement | null = null;

  loginForm!: FormGroup;
  nomeCarregado: boolean = false;

  constructor(
    private socketService: SocketService,
    private router: Router,
    private alertController: AlertController,
    private navCtrl: NavController,
    private cdr: ChangeDetectorRef,
    private api: ApiService,
    private fb: FormBuilder,
    private loadingController: LoadingController,
    private platform: Platform
  ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      cpf: ['', [Validators.required, Validators.pattern(/^\d{11}$/)]],
      nome: ['', Validators.required],
      sessionId: ['', [Validators.required, Validators.minLength(8)]]
    });

    // Observa as mudanças no campo CPF para buscar o nome
    this.loginForm.get('cpf')?.valueChanges
      .pipe(
        debounceTime(700),
        distinctUntilChanged()
      )
      .subscribe(cpf => {
        if (cpf && cpf.length === 11) {
          this.buscarNomePorCpf(cpf);
        } else {
          this.loginForm.get('nome')?.setValue('');
          this.loginForm.get('nome')?.enable();
          this.nomeCarregado = false;
          this.errorMessage = '';
        }
      });

    this.subscriptions.add(this.socketService.onJoinError().subscribe(async (message) => {
      await this.dismissLoading();
      const alert = await this.alertController.create({
        header: 'Erro ao Entrar',
        message: message,
        buttons: ['OK'],
      });
      await alert.present();
    }));

    this.subscriptions.add(this.socketService.onPreviousMessages().subscribe(async (messages) => {
      await this.dismissLoading();
      const { sessionId, cpf, nome } = this.loginForm.getRawValue();
      console.log('Recebido previousMessages, navegando para session-room');
      this.navigateToSession(sessionId, cpf, nome, messages);
    }));
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  async buscarNomePorCpf(cpf: string) {
    this.nomeCarregado = false;
    this.errorMessage = '';

    try {
      const response = await this.api.buscarUsuarioPorCpf(cpf).toPromise();

      if (response && response.nome) {
        this.loginForm.get('nome')?.setValue(response.nome);
        this.loginForm.get('nome')?.disable();
        this.nomeCarregado = true;
        console.log('Nome carregado do Firebase:', response.nome);
      } else {
        this.loginForm.get('nome')?.setValue('');
        this.loginForm.get('nome')?.enable();
        this.nomeCarregado = false;
        this.errorMessage = 'CPF não encontrado ou sem nome associado. Por favor, preencha seu nome.';
        console.log('CPF não encontrado no Firebase ou sem nome associado.');
      }
    } catch (error: any) {
      console.error('Erro ao buscar CPF no Firebase:', error);
      this.loginForm.get('nome')?.setValue('');
      this.loginForm.get('nome')?.enable();
      this.nomeCarregado = false;
      if (error.status === 404) {
        this.errorMessage = 'CPF não encontrado. Preencha seu nome para criar um novo registro.';
      } else {
        this.errorMessage = 'Erro ao buscar dados. Tente novamente mais tarde.';
      }
    }
  }

  async joinSession(event?: Event) {
    console.log('🚀 joinSession() chamado!');
    
    // Prevenir comportamento padrão do form se o evento existir
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      console.log('🛑 Evento preventDefault aplicado');
    }
    
    console.log('📋 Estado do formulário:', this.loginForm.value);
    console.log('✅ Formulário válido:', this.loginForm.valid);
    console.log('🔒 Botão desabilitado:', this.loginForm.invalid);
    
    this.errorMessage = '';

    if (this.loginForm.invalid) {
      console.log('❌ Formulário inválido, marcando campos como touched');
      this.loginForm.markAllAsTouched();
      this.presentAlert('Erro', 'Por favor, preencha todos os campos corretamente.');
      return;
    }

    console.log('📱 Criando loading...');
    await this.presentLoading();
    console.log('✅ Loading criado (ou pulado se houve erro)');

    const { cpf, nome, sessionId } = this.loginForm.getRawValue();
    console.log('📝 Dados extraídos:', { cpf, nome, sessionId });

    console.log('🔥 Chamando API salvarUsuario...');
    this.api.salvarUsuario(cpf, sessionId, nome).subscribe({
      next: (res) => {
        console.log('Usuário salvo/atualizado no Firebase:', res);
        console.log('Tentando conectar via socket...');
        
        // Verificar se socket está conectado
        if (!this.socketService.isConnected()) {
          console.warn('Socket não conectado, tentando reconectar...');
          this.socketService.reconnect();
        }
        
        this.socketService.joinRoom(sessionId, cpf, nome);
        
        // Timeout de fallback - se não receber previousMessages em 6 segundos, navegar mesmo assim
        setTimeout(async () => {
          if (this.currentLoading) {
            console.warn('Timeout: não recebeu previousMessages, navegando por fallback');
            await this.dismissLoading();
            console.log('Navegando diretamente para session-room...');
            this.navigateToSession(sessionId, cpf, nome, []);
          }
        }, 6000);
      },
      error: async (err) => {
        console.error('❌ Erro na API salvarUsuario:', err);
        console.log('📱 Removendo loading devido ao erro...');
        await this.dismissLoading();
        console.log('🚨 Mostrando alert de erro...');
        this.presentAlert('Erro', 'Não foi possível salvar seus dados. Tente novamente.');
      }
    });
  }

  async presentLoading() {
    // Pular loading no Android para evitar travamentos
    if (this.platform.is('android')) {
      console.log('📱 Android detectado - pulando loading para evitar travamento');
      this.currentLoading = null;
      return;
    }

    try {
      console.log('🔄 Criando LoadingController...');
      this.currentLoading = await this.loadingController.create({
        message: 'Entrando...',
        spinner: 'crescent'
      });
      console.log('✅ LoadingController criado, apresentando...');
      await this.currentLoading.present();
      console.log('✅ Loading apresentado com sucesso');
    } catch (error) {
      console.error('❌ Erro ao criar/apresentar loading:', error);
      // Continuar sem loading se falhar
      this.currentLoading = null;
    }
  }

  async dismissLoading() {
    if (this.currentLoading) {
      await this.currentLoading.dismiss();
      this.currentLoading = null;
    }
  }

  triggerPulse() {
    this.pulse = false;
    setTimeout(() => {
      this.pulse = true;
    }, 10);
  }

  generateId() {
    this.animatePop = false;
    setTimeout(() => {
      this.animatePop = true;
      setTimeout(() => {
        this.animatePop = false;
      }, 300);
    }, 10);
    
    // Gerar ID mais único e amigável
    const characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    this.loginForm.get('sessionId')?.setValue(`pizza-day-${result}`);
  }

  anfitriaoToggle() {
    if (this.anfitriaoBox) {
      this.usuarioBox = false;
    }
  }

  usuarioToggle() {
    if (this.usuarioBox) {
      this.anfitriaoBox = false;
    }
  }

  onCodeResult(result: string) {
    const matched = result.match(/\/join\/([a-zA-Z0-9\-]+)/);
    if (matched && matched[1]) {
      this.loginForm.get('sessionId')?.setValue(matched[1]);

      setTimeout(() => {
        this.joinSession();
      }, 300);

    } else {
      this.presentAlert('Erro', 'QR Code inválido.');
    }
  }

  private navigateToSession(sessionId: string, cpf: string, nome: string, initialParticipants?: any[]) {
    console.log(`🧭 Navegando para session-room com: roomId=${sessionId}, username=${cpf}, nome=${nome}`);
    console.log('📦 InitialParticipants:', initialParticipants);
    
    this.router.navigateByUrl('/session-room', {
      state: {
        roomId: sessionId,
        username: cpf,
        nome: nome,
        initialParticipants: initialParticipants || [],
      },
    }).then(() => {
      console.log('✅ Navegação para session-room concluída com sucesso');
    }).catch(err => {
      console.error('❌ Erro na navegação:', err);
    });
  }

  // Método de emergência para entrar diretamente na sala
  async forceJoinSession() {
    console.log('🔥 forceJoinSession() chamado!');
    const { cpf, nome, sessionId } = this.loginForm.getRawValue();
    
    if (!cpf || !nome || !sessionId) {
      this.presentAlert('Erro', 'Preencha todos os campos primeiro.');
      return;
    }

    console.log('Forçando entrada na sala...');
    await this.dismissLoading();
    this.navigateToSession(sessionId, cpf, nome, []);
  }

  // Método de teste para verificar se os eventos estão funcionando
  testClick() {
    console.log('🧪 testClick() funcionando!');
    alert('Botão está funcionando!');
  }

  // Método alternativo sem loading para teste
  async joinSessionWithoutLoading() {
    console.log('🚀 joinSessionWithoutLoading() chamado!');
    
    if (this.loginForm.invalid) {
      this.presentAlert('Erro', 'Por favor, preencha todos os campos corretamente.');
      return;
    }

    const { cpf, nome, sessionId } = this.loginForm.getRawValue();
    console.log('📝 Dados extraídos:', { cpf, nome, sessionId });

    console.log('🔥 Chamando API salvarUsuario SEM loading...');
    this.api.salvarUsuario(cpf, sessionId, nome).subscribe({
      next: (res) => {
        console.log('✅ API respondeu:', res);
        console.log('🧭 Navegando diretamente...');
        this.navigateToSession(sessionId, cpf, nome, []);
      },
      error: (err) => {
        console.error('❌ Erro na API:', err);
        this.presentAlert('Erro', 'Não foi possível salvar seus dados. Tente novamente.');
      }
    });
  }

  async presentAlert(header: string, message: string) {
    // Definir errorMessage para mostrar no template também
    this.errorMessage = message;
    setTimeout(() => {
      this.errorMessage = '';
    }, 4000);

    // Criar alert popup real para garantir consistência entre plataformas
    try {
      const alert = await this.alertController.create({
        header: header,
        message: message,
        buttons: ['OK'],
        backdropDismiss: true,
      });
      await alert.present();
    } catch (error) {
      console.error('Erro ao apresentar alert:', error);
      console.log(`ALERT: ${header} - ${message}`);
    }
  }
}