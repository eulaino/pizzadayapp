const express = require('express');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');
const fs = require('fs-extra');
const USERS_FILE = path.join(__dirname, 'users.json');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

const cors = require('cors');

const admin = require('firebase-admin');
const serviceAccount = require('./firebase-key.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://pizzaday-5a0cf-default-rtdb.firebaseio.com"
});

const db = admin.database();

app.use(cors());
app.set('views', path.join(__dirname, 'public'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.use(express.json());

// Objeto para armazenar o estado das salas em memória (para performance)
const roomStates = {};

// ============ FUNÇÕES DE PERSISTÊNCIA FIREBASE (MELHORADAS) ============

// Função para garantir que a sala existe e está ativa
async function ensureRoomExists(roomId, createdBy = null) {
    try {
        console.log(`🔍 Verificando existência da sala: ${roomId}`);
        
        const infoSnapshot = await db.ref(`salas/${roomId}/info`).once('value');
        
        if (!infoSnapshot.exists()) {
            console.log(`🆕 Criando nova sala: ${roomId}`);
            // Criar sala se não existir
            await db.ref(`salas/${roomId}/info`).set({
                roomId: roomId,
                createdBy: createdBy || 'system',
                createdAt: Date.now(),
                isActive: true,
                lastActivity: Date.now()
            });
            
            // Criar configurações padrão
            const defaultSettings = {
                divisionType: 'consumption',
                showQRCode: true,
                pizzas: [],
                globalSlices: {},
                createdBy: createdBy || 'system',
                createdAt: Date.now(),
                updatedAt: Date.now()
            };
            
            await db.ref(`salas/${roomId}/settings`).set(defaultSettings);
            console.log(`✅ Sala ${roomId} criada com configurações padrão`);
            return true;
        } else {
            const info = infoSnapshot.val();
            const isActive = info.isActive !== false; // Padrão é ativa se não especificado
            
            if (isActive) {
                // Atualizar última atividade
                await db.ref(`salas/${roomId}/info`).update({
                    lastActivity: Date.now()
                });
                console.log(`✅ Sala ${roomId} está ativa`);
                return true;
            } else {
                console.log(`❌ Sala ${roomId} foi encerrada`);
                return false;
            }
        }
    } catch (error) {
        console.error('Erro ao verificar/criar sala:', error);
        // Em caso de erro, assumir que sala está ativa (para não bloquear)
        return true;
    }
}

// Função para salvar participante no Firebase (com fallback)
async function saveParticipantToFirebase(roomId, cpf, nome, pizza = 0, isHost = false, socketId = null) {
    try {
        console.log(`💾 Salvando participante: ${nome} na sala ${roomId}`);
        
        await db.ref(`salas/${roomId}/participants/${cpf}`).set({
            nome: nome,
            cpf: cpf,
            pizza: pizza,
            isHost: isHost,
            socketId: socketId,
            lastSeen: Date.now(),
            isOnline: true,
            joinedAt: Date.now()
        });
        
        console.log(`✅ Participante ${nome} salvo no Firebase`);
        return true;
    } catch (error) {
        console.error('Erro ao salvar participante no Firebase:', error);
        return false;
    }
}

// Função para atualizar status online do participante
async function updateParticipantOnlineStatus(roomId, cpf, isOnline, socketId = null) {
    try {
        const updates = {
            isOnline: isOnline,
            lastSeen: Date.now()
        };
        
        if (socketId) {
            updates.socketId = socketId;
        }
        
        await db.ref(`salas/${roomId}/participants/${cpf}`).update(updates);
        return true;
    } catch (error) {
        console.error('Erro ao atualizar status online:', error);
        return false;
    }
}

// Função para buscar participantes da sala no Firebase (com fallback)
async function getRoomParticipantsFromFirebase(roomId) {
    try {
        console.log(`📋 Buscando participantes da sala: ${roomId}`);
        
        const snapshot = await db.ref(`salas/${roomId}/participants`).once('value');
        const participants = [];
        
        if (snapshot.exists()) {
            const participantsData = snapshot.val();
            for (const cpf in participantsData) {
                const participant = participantsData[cpf];
                participants.push({
                    author: participant.nome,
                    pizza: participant.pizza || 0,
                    roomId: roomId,
                    isHost: participant.isHost || false,
                    cpf: cpf,
                    isOnline: participant.isOnline !== false, // Padrão é online
                    lastSeen: participant.lastSeen || Date.now()
                });
            }
        }
        
        console.log(`✅ Encontrados ${participants.length} participantes na sala ${roomId}`);
        return participants;
    } catch (error) {
        console.error('Erro ao buscar participantes do Firebase:', error);
        return [];
    }
}

// Função para verificar se um usuário é host no Firebase (com fallback)
async function checkIfUserIsHostInFirebase(cpf, roomId) {
    try {
        // Primeiro tentar na nova estrutura
        const participantSnapshot = await db.ref(`salas/${roomId}/participants/${cpf}`).once('value');
        if (participantSnapshot.exists()) {
            const userData = participantSnapshot.val();
            return userData.isHost === true;
        }
        
        // Fallback para estrutura antiga
        const userSnapshot = await db.ref(`usuarios/${cpf}`).once('value');
        if (userSnapshot.exists()) {
            const userData = userSnapshot.val();
            return userData.isHost === true && userData.roomId === roomId;
        }
        
        return false;
    } catch (error) {
        console.error('Erro ao verificar host no Firebase:', error);
        return false;
    }
}

// Função para definir usuário como host no Firebase
async function setUserAsHostInFirebase(cpf, roomId, nome) {
    try {
        // Atualizar no participantes da sala
        await db.ref(`salas/${roomId}/participants/${cpf}`).update({
            isHost: true,
            updatedAt: Date.now()
        });
        
        // Também manter na estrutura de usuários para compatibilidade
        await db.ref(`usuarios/${cpf}`).update({
            nome: nome,
            roomId: roomId,
            isHost: true,
            updatedAt: Date.now()
        });
        
        console.log(`✅ ${nome} definido como host da sala ${roomId}`);
        return true;
    } catch (error) {
        console.error('Erro ao definir host no Firebase:', error);
        return false;
    }
}

// Função para salvar configurações da sala
async function saveRoomSettingsToFirebase(roomId, settings, createdBy) {
  try {
    const settingsRef = db.ref(`salas/${roomId}/settings`);
    const snap = await settingsRef.once('value');
    const prev = snap.exists() ? snap.val() : {};
    const now = Date.now();

    const incoming = { ...(settings || {}) };
    let next = {
      ...prev,              // base: o que já existe
      ...incoming,          // sobrescreve com o que chegou
      roomId,
      createdBy,
      updatedAt: now
    };

    // Se não veio globalSlices, preserve o atual
    if (incoming.globalSlices === undefined) {
      next.globalSlices = prev.globalSlices || {};
      next.slicesUpdatedAt = prev.slicesUpdatedAt || prev.updatedAt || now;
    } else {
      // Se veio globalSlices mas é mais antigo que o já salvo, mantenha o mais novo
      const incomingTs = incoming.slicesUpdatedAt || incoming.timestamp || 0;
      if (prev.slicesUpdatedAt && incomingTs && incomingTs < prev.slicesUpdatedAt) {
        next.globalSlices = prev.globalSlices || {};
        next.slicesUpdatedAt = prev.slicesUpdatedAt;
      } else {
        next.slicesUpdatedAt = incomingTs || now;
      }
    }

    await settingsRef.set(next);
    await db.ref(`salas/${roomId}/info`).update({ lastActivity: now });

    console.log(`✅ Configurações da sala ${roomId} salvas (merge seguro)`);
    return true;
  } catch (error) {
    console.error('Erro ao salvar configurações no Firebase:', error);
    return false;
  }
}

// Função para buscar configurações de uma sala (com fallback)
async function getRoomSettings(roomId) {
    try {
        console.log(`⚙️ Buscando configurações da sala: ${roomId}`);
        
        const snapshot = await db.ref(`salas/${roomId}/settings`).once('value');
        if (snapshot.exists()) {
            console.log(`✅ Configurações encontradas para sala ${roomId}`);
            return snapshot.val();
        }
        
        console.log(`ℹ️ Nenhuma configuração encontrada para sala ${roomId}`);
        return null;
    } catch (error) {
        console.error('Erro ao buscar configurações da sala:', error);
        return null;
    }
}

// Função para verificar se a sala existe e está ativa (com fallback mais permissivo)
async function isRoomActive(roomId) {
    try {
        const snapshot = await db.ref(`salas/${roomId}/info`).once('value');
        if (snapshot.exists()) {
            const info = snapshot.val();
            return info.isActive !== false; // Padrão é ativa se não especificado
        }
        
        // Se não existe info, verificar se tem participantes ou configurações
        const settingsSnapshot = await db.ref(`salas/${roomId}/settings`).once('value');
        const participantsSnapshot = await db.ref(`salas/${roomId}/participants`).once('value');
        
        if (settingsSnapshot.exists() || participantsSnapshot.exists()) {
            console.log(`ℹ️ Sala ${roomId} existe mas sem info, assumindo ativa`);
            return true;
        }
        
        console.log(`ℹ️ Sala ${roomId} não existe ainda, será criada`);
        return true; // Permitir criação de nova sala
    } catch (error) {
        console.error('Erro ao verificar status da sala:', error);
        return true; // Em caso de erro, assumir ativa para não bloquear
    }
}

// Função para encerrar sala
async function endRoomInFirebase(roomId, endedBy) {
    try {
        await db.ref(`salas/${roomId}/info`).update({
            isActive: false,
            endedAt: Date.now(),
            endedBy: endedBy
        });
        
        // Marcar todos os participantes como offline
        const participantsSnapshot = await db.ref(`salas/${roomId}/participants`).once('value');
        if (participantsSnapshot.exists()) {
            const participants = participantsSnapshot.val();
            const updates = {};
            
            for (const cpf in participants) {
                updates[`${cpf}/isOnline`] = false;
                updates[`${cpf}/leftAt`] = Date.now();
            }
            
            await db.ref(`salas/${roomId}/participants`).update(updates);
        }
        
        console.log(`✅ Sala ${roomId} encerrada por ${endedBy}`);
        return true;
    } catch (error) {
        console.error('Erro ao encerrar sala:', error);
        return false;
    }
}

// ============ FUNÇÕES AUXILIARES ============

// Função auxiliar para encontrar o NOME COMPLETO do usuário pelo socketId
function findNomeCompletoBySocketId(roomId, socketId) {
    if (roomStates[roomId] && roomStates[roomId].users) {
        for (const authorKey in roomStates[roomId].users) {
            if (roomStates[roomId].users[authorKey].socketId === socketId) {
                return authorKey;
            }
        }
    }
    return null;
}

// Sanitizador de globalSlices para garantir números inteiros >= 0
function sanitizeGlobalSlices(slices) {
  const safe = {};
  if (!slices || typeof slices !== 'object') return safe;
  for (const pIdx of Object.keys(slices)) {
    const perUser = slices[pIdx] || {};
    const safePerUser = {};
    for (const user of Object.keys(perUser)) {
      let v = perUser[user];
      if (typeof v !== 'number' || !isFinite(v)) v = 0;
      v = Math.max(0, Math.floor(v));
      if (v > 0) safePerUser[user] = v;
    }
    if (Object.keys(safePerUser).length > 0) safe[pIdx] = safePerUser;
  }
  return safe;
}

// Atualiza apenas globalSlices no Firebase (leve e atômico)
async function updateGlobalSlicesInFirebase(roomId, globalSlices, updatedBy = 'system') {
  try {
    const safe = sanitizeGlobalSlices(globalSlices);
    const settingsRef = db.ref(`salas/${roomId}/settings`);
    const now = Date.now();

    await settingsRef.update({
      globalSlices: safe,
      slicesUpdatedAt: now,
      updatedAt: now,
      updatedBy
    });

    await db.ref(`salas/${roomId}/info`).update({ lastActivity: now });

    console.log(`✅ globalSlices persistido para sala ${roomId}`);
    return true;
  } catch (error) {
    console.error('❌ Erro ao salvar globalSlices no Firebase:', error);
    return false;
  }
}

// ============ ROTAS HTTP (MELHORADAS) ============

app.post('/login', async (req, res) => {
    console.log("🚀 Processando login...");
    const { username, roomId, nome } = req.body;
    console.log('📝 Login request:', { username, roomId, nome });

    fs.readFile(USERS_FILE, 'utf-8', async (err, data) => {
        if (err) {
            console.error('❌ Erro ao ler users.json:', err);
            return res.status(500).json({ message: 'Erro no servidor' });
        }

        try {
            const json = JSON.parse(data);
            console.log('📂 Salas disponíveis:', Object.keys(json.salas));

            if (json.salas && json.salas[roomId] && json.salas[roomId].includes(username)) {
                console.log('✅ Login autorizado via users.json!');

                // Garantir que a sala existe (criar se necessário)
                const roomActive = await ensureRoomExists(roomId, username);
                if (!roomActive) {
                    console.log('❌ Sala encerrada ou erro ao criar');
                    return res.status(410).json({ message: 'Esta sala foi encerrada' });
                }

                // Verificar se o usuário já é host desta sala
                const isCurrentHost = await checkIfUserIsHostInFirebase(username, roomId);
                console.log(`👑 ${nome} é host: ${isCurrentHost}`);

                try {
                    // Salvar/atualizar usuário
                    await saveParticipantToFirebase(roomId, username, nome, 0, isCurrentHost);
                    
                    // Manter estrutura antiga para compatibilidade
                    await db.ref(`usuarios/${username}`).update({
                        nome: nome,
                        roomId: roomId,
                        isHost: isCurrentHost,
                        updatedAt: Date.now()
                    });
                    
                    console.log(`✅ Dados do usuário ${nome} atualizados`);
                } catch (firebaseUpdateErr) {
                    console.error('⚠️ Erro ao atualizar Firebase (continuando):', firebaseUpdateErr);
                }

                return res.status(200).json({
                    message: 'Login autorizado',
                    username: username,
                    nome: nome,
                    isHost: isCurrentHost
                });
            } else {
                console.log('❌ Login negado - usuário ou sala inválidos');
                return res.status(401).json({ message: 'Usuário ou sala inválidos' });
            }
        } catch (parseErr) {
            console.error('❌ Erro ao parsear JSON:', parseErr);
            return res.status(500).json({ message: 'Erro ao processar dados' });
        }
    });
});

// Rota para buscar configurações da sala (melhorada)
app.get('/api/room-settings/:roomId', async (req, res) => {
    const { roomId } = req.params;
    console.log(`🔍 Buscando configurações da sala: ${roomId}`);

    try {
        // Garantir que a sala existe
        const roomActive = await ensureRoomExists(roomId);
        if (!roomActive) {
            return res.status(410).json({ message: 'Esta sala foi encerrada' });
        }

        let settings = await getRoomSettings(roomId);
        if (settings) {
            console.log(`✅ Configurações encontradas para ${roomId}`);
            return res.status(200).json(settings);
        } else {
            console.log(`ℹ️ Criando configurações padrão para ${roomId}`);
            // Retornar e PERSISTIR configurações padrão se não existirem
            const defaultSettings = {
                divisionType: 'consumption',
                showQRCode: true,
                pizzas: [],
                globalSlices: {},
                createdAt: Date.now(),
                updatedAt: Date.now()
            };
            await db.ref(`salas/${roomId}/settings`).set(defaultSettings);
            await db.ref(`salas/${roomId}/info`).update({ lastActivity: Date.now() });
            return res.status(200).json(defaultSettings);
        }
    } catch (error) {
        console.error('❌ Erro ao buscar configurações da sala:', error);
        return res.status(500).json({ message: 'Erro no servidor' });
    }
});

// Rota para verificar status da sala (melhorada)
app.get('/api/room-status/:roomId', async (req, res) => {
    const { roomId } = req.params;
    console.log(`🔍 Verificando status da sala: ${roomId}`);

    try {
        const roomActive = await isRoomActive(roomId);
        const settings = roomActive ? await getRoomSettings(roomId) : null;
        
        console.log(`📊 Status da sala ${roomId}: ativa=${roomActive}`);
        
        return res.status(200).json({
            isActive: roomActive,
            settings: settings
        });
    } catch (error) {
        console.error('❌ Erro ao verificar status da sala:', error);
        // Em caso de erro, assumir que está ativa
        return res.status(200).json({
            isActive: true,
            settings: null
        });
    }
});

// Outras rotas mantidas...
app.post('/api/usuarios', async (req, res) => {
    const { nome, username, roomId } = req.body;

    if (!username || !roomId || !nome) {
        return res.status(400).json({ message: 'Campos obrigatórios faltando' });
    }

    try {
        const roomActive = await ensureRoomExists(roomId, username);
        if (!roomActive) {
            return res.status(410).json({ message: 'Esta sala foi encerrada' });
        }

        const existingParticipants = await getRoomParticipantsFromFirebase(roomId);
        const existingHosts = existingParticipants.filter(p => p.isHost);
        const isFirstHost = existingHosts.length === 0;

        await saveParticipantToFirebase(roomId, username, nome, 0, isFirstHost);

        await db.ref(`usuarios/${username}`).set({
            nome,
            username,
            roomId,
            createdAt: Date.now(),
            isHost: isFirstHost
        });

        res.status(201).json({
            message: 'Usuário salvo com sucesso',
            isHost: isFirstHost
        });
    } catch (error) {
        console.error('Erro ao salvar usuário:', error);
        res.status(500).json({ message: 'Erro ao salvar usuário' });
    }
});

app.get('/api/usuarios/:cpf', async (req, res) => {
    const { cpf } = req.params;

    try {
        const snapshot = await db.ref(`usuarios/${cpf}`).once('value');
        if (!snapshot.exists()) {
            return res.status(404).json({ message: 'CPF não encontrado' });
        }

        const dados = snapshot.val();
        
        if (dados.roomId) {
            const roomActive = await isRoomActive(dados.roomId);
            if (!roomActive) {
                return res.status(410).json({ message: 'A sala deste usuário foi encerrada' });
            }
        }

        return res.status(200).json({
            username: dados.username,
            nome: dados.nome,
            roomId: dados.roomId,
            isHost: dados.isHost || false
        });
    } catch (error) {
        console.error('Erro ao buscar usuário por CPF:', error);
        return res.status(500).json({ message: 'Erro no servidor' });
    }
});

app.post('/api/set-host', async (req, res) => {
    const { cpf, roomId, nome } = req.body;

    if (!cpf || !roomId || !nome) {
        return res.status(400).json({ message: 'Campos obrigatórios faltando' });
    }

    try {
        const roomActive = await ensureRoomExists(roomId);
        if (!roomActive) {
            return res.status(410).json({ message: 'Esta sala foi encerrada' });
        }

        const success = await setUserAsHostInFirebase(cpf, roomId, nome);
        if (success) {
            io.to(roomId).emit('hostStatusChanged', {
                roomId: roomId,
                newHost: nome,
                action: 'added'
            });

            res.status(200).json({ message: 'Host definido com sucesso' });
        } else {
            res.status(500).json({ message: 'Erro ao definir host' });
        }
    } catch (error) {
        console.error('Erro ao definir host:', error);
        res.status(500).json({ message: 'Erro no servidor' });
    }
});

app.post('/api/room-settings', async (req, res) => {
    const settings = req.body;
    const { roomId, createdBy } = settings;

    if (!roomId || !createdBy) {
        return res.status(400).json({ message: 'roomId e createdBy são obrigatórios' });
    }

    try {
        const roomActive = await ensureRoomExists(roomId, createdBy);
        if (!roomActive) {
            return res.status(410).json({ message: 'Esta sala foi encerrada' });
        }

        const success = await saveRoomSettingsToFirebase(roomId, settings, createdBy);
        
        if (success) {
            res.status(201).json({
                message: 'Configurações da sala salvas com sucesso',
                roomId: roomId
            });
        } else {
            res.status(500).json({ message: 'Erro ao salvar configurações' });
        }
    } catch (error) {
        console.error('Erro ao salvar configurações da sala:', error);
        res.status(500).json({ message: 'Erro ao salvar configurações da sala' });
    }
});

app.post('/api/end-room/:roomId', async (req, res) => {
    const { roomId } = req.params;
    const { cpf, endedBy } = req.body;

    if (!cpf || !endedBy) {
        return res.status(400).json({ message: 'CPF e endedBy são obrigatórios' });
    }

    try {
        const isHost = await checkIfUserIsHostInFirebase(cpf, roomId);
        if (!isHost) {
            return res.status(403).json({ message: 'Apenas hosts podem encerrar a sala' });
        }

        const success = await endRoomInFirebase(roomId, endedBy);
        
        if (success) {
            if (roomStates[roomId]) {
                delete roomStates[roomId];
            }
            
            io.to(roomId).emit('roomEnded', {
                roomId: roomId,
                endedBy: endedBy,
                timestamp: Date.now()
            });
            
            res.status(200).json({ message: 'Sala encerrada com sucesso' });
        } else {
            res.status(500).json({ message: 'Erro ao encerrar sala' });
        }
    } catch (error) {
        console.error('Erro ao encerrar sala:', error);
        res.status(500).json({ message: 'Erro no servidor' });
    }
});

app.post('/api/save-user-state', async (req, res) => {
    const { roomId, username, cpf, pizza, userSliceData, lastSeen } = req.body;

    if (!roomId || !username || !cpf) {
        return res.status(400).json({ message: 'Campos obrigatórios faltando' });
    }

    try {
        await db.ref(`salas/${roomId}/participants/${cpf}`).update({
            pizza: pizza || 0,
            userSliceData: userSliceData || {},
            lastSeen: lastSeen || Date.now()
        });

        res.status(200).json({ message: 'Estado do usuário salvo' });
    } catch (error) {
        console.error('Erro ao salvar estado do usuário:', error);
        res.status(500).json({ message: 'Erro ao salvar estado' });
    }
});

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.render('index.html');
});

// ============ SOCKET.IO HANDLERS (MELHORADOS) ============

io.on('connection', socket => {
    console.log(`🔌 Socket conectado: ${socket.id}`);

    socket.on('joinRoom', async (data) => {
        const { roomId, username: cpf } = data;
        console.log(`🚪 ENTRADA NA SALA: ${roomId} por ${cpf}`);

        try {
            // Garantir que a sala existe e está ativa
            const roomActive = await ensureRoomExists(roomId, cpf);
            if (!roomActive) {
                console.log(`❌ Sala ${roomId} não está ativa`);
                socket.emit('roomEnded', {
                    roomId: roomId,
                    message: 'Esta sala foi encerrada'
                });
                return;
            }

            // Buscar dados do usuário (com fallbacks múltiplos)
            let nomeCompleto = null;
            let isHostInFirebase = false;
            let userPizza = 0;

            console.log(`🔍 Buscando dados para CPF: ${cpf}`);
            
            // Primeiro tentar na estrutura de participantes da sala
            const participantSnapshot = await db.ref(`salas/${roomId}/participants/${cpf}`).once('value');
            if (participantSnapshot.exists()) {
                const userData = participantSnapshot.val();
                nomeCompleto = userData.nome;
                isHostInFirebase = userData.isHost === true;
                userPizza = userData.pizza || 0;
                console.log(`✅ Dados do participante encontrados: ${nomeCompleto} (Host: ${isHostInFirebase})`);
            } else {
                // Fallback para estrutura antiga de usuários
                const userSnapshot = await db.ref(`usuarios/${cpf}`).once('value');
                if (userSnapshot.exists()) {
                    const userData = userSnapshot.val();
                    nomeCompleto = userData.nome;
                    isHostInFirebase = userData.isHost === true && userData.roomId === roomId;
                    console.log(`✅ Dados do usuário (estrutura antiga): ${nomeCompleto} (Host: ${isHostInFirebase})`);
                    
                    // Migrar para nova estrutura
                    await saveParticipantToFirebase(roomId, cpf, nomeCompleto, userPizza, isHostInFirebase);
                } else {
                    console.warn(`⚠️ NENHUM DADO ENCONTRADO para CPF ${cpf}!`);
                    nomeCompleto = cpf; // Usar CPF como nome temporário
                    isHostInFirebase = false;
                    
                    // Criar entrada básica
                    await saveParticipantToFirebase(roomId, cpf, nomeCompleto, 0, false);
                }
            }

            socket.data.cpf = cpf;
            socket.data.nomeCompleto = nomeCompleto;
            socket.data.isHost = isHostInFirebase;
            socket.data.roomId = roomId;

            // Sair de salas anteriores
            Object.keys(socket.rooms).forEach(room => {
                if (room !== socket.id && room !== roomId) {
                    socket.leave(room);
                    console.log(`↩️ Socket ${socket.id} deixou sala anterior: ${room}`);
                }
            });

            // Verificar duplicatas (mais permissivo agora)
            if (roomStates[roomId] && roomStates[roomId].users && roomStates[roomId].users[nomeCompleto]) {
                const existingUser = roomStates[roomId].users[nomeCompleto];
                console.log(`⚠️ Usuário ${nomeCompleto} já existe na sala, atualizando socket`);
                existingUser.socketId = socket.id;
            }

            socket.join(roomId);
            console.log(`✅ ${nomeCompleto} CONECTADO na sala ${roomId} (Host: ${isHostInFirebase})`);

            // Criar sala em memória se não existir
            if (!roomStates[roomId]) {
                roomStates[roomId] = { users: {} };
                console.log(`🏠 Sala ${roomId} criada em memória`);
            }

            // Adicionar usuário à sala
            roomStates[roomId].users[nomeCompleto] = {
                pizza: userPizza,
                socketId: socket.id,
                cpf: cpf,
                isHost: isHostInFirebase
            };

            // Atualizar status online no Firebase
            await updateParticipantOnlineStatus(roomId, cpf, true, socket.id);

            // Buscar TODOS os participantes (online e offline)
            const allParticipants = await getRoomParticipantsFromFirebase(roomId);
            console.log(`📋 Participantes encontrados: ${allParticipants.length}`);
            
            const activeParticipants = allParticipants.map(p => ({
                author: p.author,
                pizza: p.pizza,
                roomId: roomId,
                isHost: p.isHost
            }));

            // Carregar e enviar configurações SEMPRE
            try {
                let roomSettings = await getRoomSettings(roomId);
                if (!roomSettings) {
                    console.log(`⚙️ Criando configurações padrão para sala ${roomId}`);
                    roomSettings = {
                        divisionType: 'consumption',
                        showQRCode: true,
                        pizzas: [],
                        globalSlices: {},
                        createdBy: cpf,
                        createdAt: Date.now(),
                        updatedAt: Date.now()
                    };
                    
                    await saveRoomSettingsToFirebase(roomId, roomSettings, cpf);
                }

                console.log(`📤 Enviando configurações para ${nomeCompleto}:`, {
                    pizzas: roomSettings.pizzas?.length || 0,
                    divisionType: roomSettings.divisionType,
                    globalSlices: Object.keys(roomSettings.globalSlices || {}).length
                });

                socket.emit('roomSettingsResponse', {
                    roomId: roomId,
                    settings: roomSettings
                });
            } catch (settingsError) {
                console.error('⚠️ Erro ao carregar configurações (enviando padrão):', settingsError);
                socket.emit('roomSettingsResponse', {
                    roomId: roomId,
                    settings: {
                        divisionType: 'consumption',
                        showQRCode: true,
                        pizzas: [],
                        globalSlices: {}
                    }
                });
            }

            // Enviar dados iniciais
            console.log(`📤 Enviando dados iniciais para ${nomeCompleto}`);
            socket.emit('previousMessages', activeParticipants);
            socket.emit('youAreHost', { isHost: isHostInFirebase });

            socket.emit('roomJoined', {
                roomId: roomId,
                participants: activeParticipants,
                isHost: isHostInFirebase
            });

            // Notificar TODOS na sala sobre novo participante
            console.log(`📢 Notificando sala sobre entrada de ${nomeCompleto}`);
            io.to(roomId).emit('receivedMessage', {
                author: nomeCompleto,
                pizza: userPizza,
                roomId: roomId,
                isHost: isHostInFirebase
            });

            console.log(`🎉 ${nomeCompleto} CONECTADO COM SUCESSO! Participantes ativos: ${activeParticipants.length}`);

        } catch (error) {
            console.error('❌ ERRO CRÍTICO ao processar joinRoom:', error);
            socket.emit('joinError', 'Erro interno do servidor. Tente novamente em alguns segundos.');
        }
    });

    // Outros handlers mantidos com logs melhorados...
    socket.on('heartbeat', async (data) => {
        const { roomId } = data;
        if (roomId && socket.data.cpf) {
            await updateParticipantOnlineStatus(roomId, socket.data.cpf, true, socket.id);
        }
    });

    socket.on('updateRoomSettings', async (data) => {
        const { roomId, settings, updatedBy } = data;
        console.log(`⚙️ Atualizando configurações da sala ${roomId} por ${updatedBy}`);

        try {
            const roomActive = await isRoomActive(roomId);
            if (!roomActive) {
                socket.emit('roomEnded', { roomId: roomId, message: 'Esta sala foi encerrada' });
                return;
            }

            const cpf = socket.data.cpf;
            const isHost = await checkIfUserIsHostInFirebase(cpf, roomId);

            if (!isHost) {
                socket.emit('error', 'Apenas hosts podem atualizar configurações da sala');
                return;
            }

            const success = await saveRoomSettingsToFirebase(roomId, settings, cpf);
            
            if (success) {
                io.to(roomId).emit('roomSettingsUpdated', {
                    roomId: roomId,
                    settings: settings,
                    updatedBy: updatedBy,
                    updatedAt: Date.now()
                });

                console.log(`✅ Configurações da sala ${roomId} atualizadas`);
            } else {
                socket.emit('error', 'Erro ao salvar configurações da sala');
            }

        } catch (error) {
            console.error('❌ Erro ao atualizar configurações:', error);
            socket.emit('error', 'Erro ao salvar configurações da sala');
        }
    });

    socket.on('getRoomSettings', async (data) => {
        const { roomId } = data;
        console.log(`⚙️ Configurações solicitadas para sala ${roomId}`);

        try {
            const roomActive = await isRoomActive(roomId);
            if (!roomActive) {
                socket.emit('roomEnded', { roomId: roomId, message: 'Esta sala foi encerrada' });
                return;
            }

            const settings = await getRoomSettings(roomId);
            const settingsToSend = settings || {
                divisionType: 'consumption',
                showQRCode: true,
                pizzas: [],
                globalSlices: {}
            };

            socket.emit('roomSettingsResponse', {
                roomId: roomId,
                settings: settingsToSend
            });
        } catch (error) {
            console.error('❌ Erro ao buscar configurações:', error);
            socket.emit('error', 'Erro ao buscar configurações da sala');
        }
    });

    // Manter outros handlers existentes...
    socket.on('requestRoomStatus', async (data) => {
        const { roomId } = data;
        console.log(`📊 Status solicitado para sala ${roomId}`);

        try {
            const roomActive = await isRoomActive(roomId);
            if (!roomActive) {
                socket.emit('roomEnded', { roomId: roomId, message: 'Esta sala foi encerrada' });
                return;
            }

            const participants = await getRoomParticipantsFromFirebase(roomId);
            const activeParticipants = participants.filter(p => p.isOnline);
            const userIsHost = await checkIfUserIsHostInFirebase(socket.data.cpf, roomId);

            socket.emit('roomStatusResponse', {
                roomId: roomId,
                participants: activeParticipants,
                userIsHost: userIsHost
            });
        } catch (error) {
            console.error('❌ Erro ao buscar status:', error);
            socket.emit('error', 'Sala não encontrada');
        }
    });

    socket.on('checkCurrentUserHost', async (data) => {
        const { roomId } = data;
        try {
            const isHost = await checkIfUserIsHostInFirebase(socket.data.cpf, roomId);
            socket.emit('userHostStatus', {
                roomId: roomId,
                username: socket.data.nomeCompleto,
                isHost: isHost
            });
        } catch (error) {
            console.error('❌ Erro ao verificar host:', error);
        }
    });

    socket.on('checkIfHost', async ({ roomId }) => {
        const nome = socket.data.nomeCompleto;
        const cpf = socket.data.cpf;
        console.log(`👑 Verificando host: ${nome} na sala ${roomId}`);

        try {
            const isHost = await checkIfUserIsHostInFirebase(cpf, roomId);
            socket.emit('youAreHost', { isHost });
            console.log(`👑 ${nome} é host: ${isHost}`);
        } catch (error) {
            console.error('❌ Erro ao verificar host:', error);
            socket.emit('youAreHost', { isHost: false });
        }
    });

    socket.on('sendMessage', async (data) => {
        const { author, pizza, roomId } = data;

        if (socket.data.nomeCompleto !== author) {
            console.warn(`⚠️ Mensagem inválida de ${author}`);
            return;
        }

        try {
            const roomActive = await isRoomActive(roomId);
            if (!roomActive) {
                socket.emit('roomEnded', { roomId: roomId, message: 'Esta sala foi encerrada' });
                return;
            }

            if (!roomStates[roomId] || !roomStates[roomId].users[author] || 
                roomStates[roomId].users[author].socketId !== socket.id) {
                console.warn(`⚠️ Mensagem não autorizada de ${author}`);
                return;
            }

            roomStates[roomId].users[author].pizza = pizza;

            await db.ref(`salas/${roomId}/participants/${socket.data.cpf}`).update({
                pizza: pizza,
                lastSeen: Date.now()
            });

            const isHost = await checkIfUserIsHostInFirebase(socket.data.cpf, roomId);

            io.to(roomId).emit('receivedMessage', {
                author: author,
                pizza: pizza,
                roomId: roomId,
                isHost: isHost
            });
            console.log(`💬 Mensagem de ${author}: ${pizza} fatias`);
        } catch (error) {
            console.error('❌ Erro ao processar mensagem:', error);
        }
    });

    socket.on('removeSliceRequest', async (data) => {
        const { roomId, authorToChange } = data;

        try {
            const isHost = await checkIfUserIsHostInFirebase(socket.data.cpf, roomId);

            if (isHost) {
                if (roomStates[roomId] && roomStates[roomId].users[authorToChange] && 
                    roomStates[roomId].users[authorToChange].pizza > 0) {
                    
                    roomStates[roomId].users[authorToChange].pizza--;

                    const targetUserCpf = roomStates[roomId].users[authorToChange].cpf;
                    await db.ref(`salas/${roomId}/participants/${targetUserCpf}`).update({
                        pizza: roomStates[roomId].users[authorToChange].pizza,
                        lastSeen: Date.now()
                    });

                    const targetIsHost = await checkIfUserIsHostInFirebase(targetUserCpf, roomId);

                    io.to(roomId).emit('receivedMessage', {
                        author: authorToChange,
                        pizza: roomStates[roomId].users[authorToChange].pizza,
                        roomId: roomId,
                        isHost: targetIsHost
                    });
                    console.log(`➖ Host removeu fatia de ${authorToChange}`);
                } else {
                    socket.emit('error', 'O usuário não tem fatias para remover.');
                }
            } else {
                socket.emit('error', 'Apenas o host pode remover fatias.');
            }
        } catch (error) {
            console.error('❌ Erro ao remover fatia:', error);
            socket.emit('error', 'Erro ao processar solicitação');
        }
    });

    // >>>>>>>>>>>>>>>> ATUALIZADO: agora persiste no Firebase <<<<<<<<<<<<<<
socket.on('updateGlobalSlices', async (data) => {
  const { roomId, globalSlices, updatedBy } = data || {};
  console.log(`📥 updateGlobalSlices recebido para sala ${roomId} (by: ${updatedBy || socket.data?.cpf})`);

  try {
    // Garante que a sala está ativa
    const roomActive = await isRoomActive(roomId);
    if (!roomActive) {
      socket.emit('roomEnded', { roomId, message: 'Esta sala foi encerrada' });
      return;
    }

    // Persiste APENAS o globalSlices (sem exigir que seja host)
    const ok = await updateGlobalSlicesInFirebase(roomId, globalSlices, updatedBy || socket.data?.cpf);
    if (!ok) {
      socket.emit('error', 'Erro ao salvar fatias no servidor');
      return;
    }

    // Reemite para todos (inclusive o autor) mantendo a mesma carga
    io.to(roomId).emit('globalSlicesUpdated', data);

    console.log(`📤 globalSlicesUpdated emitido para sala ${roomId}`);

  } catch (error) {
    console.error('❌ Erro no handler updateGlobalSlices:', error);
    socket.emit('error', 'Erro ao processar atualização de fatias');
  }
});

    socket.on('leaveRoom', async (roomId) => {
        const nomeCompletoLeaving = socket.data.nomeCompleto;
        const cpf = socket.data.cpf;

        if (socket.rooms.has(roomId)) {
            socket.leave(roomId);
            console.log(`👋 ${nomeCompletoLeaving} saiu da sala ${roomId}`);

            if (nomeCompletoLeaving && roomStates[roomId] && roomStates[roomId].users[nomeCompletoLeaving]) {
                delete roomStates[roomId].users[nomeCompletoLeaving];

                if (cpf) {
                    await updateParticipantOnlineStatus(roomId, cpf, false);
                }

                io.to(roomId).emit('userLeft', { author: nomeCompletoLeaving, roomId: roomId });

                if (Object.keys(roomStates[roomId].users).length === 0) {
                    delete roomStates[roomId];
                    console.log(`🗑️ Sala ${roomId} removida da memória`);
                }
            }
        }
    });

    // ⚠️ Removido o handler DUPLICADO que apenas reemitia roomSettingsUpdated sem salvar
    // socket.on('updateRoomSettings', (data) => {
    //     socket.to(data.roomId).emit('roomSettingsUpdated', data);
    // });

    socket.on('disconnect', async () => {
        console.log(`🔌 Socket desconectado: ${socket.id}`);
        
        const roomId = socket.data.roomId;
        const cpf = socket.data.cpf;
        const nomeCompleto = socket.data.nomeCompleto;

        if (roomId && cpf) {
            await updateParticipantOnlineStatus(roomId, cpf, false);
        }

        for (const currentRoomId in roomStates) {
            if (roomStates[currentRoomId] && roomStates[currentRoomId].users) {
                for (const authorKey in { ...roomStates[currentRoomId].users }) {
                    const user = roomStates[currentRoomId].users[authorKey];
                    if (user && user.socketId === socket.id) {
                        delete roomStates[currentRoomId].users[authorKey];
                        console.log(`🗑️ ${authorKey} removido da sala ${currentRoomId}`);
                        
                        io.to(currentRoomId).emit('userLeft', { 
                            author: authorKey, 
                            roomId: currentRoomId 
                        });

                        if (Object.keys(roomStates[currentRoomId].users).length === 0) {
                            delete roomStates[currentRoomId];
                            console.log(`🗑️ Sala ${currentRoomId} removida da memória`);
                        }
                        break;
                    }
                }
            }
        }
    });
});

server.listen(3000, '0.0.0.0', () => {
    console.log(`🚀 Servidor rodando na porta 3000`);
    console.log('💾 Sistema de persistência com fallbacks ativo');
    console.log('🔧 Criação automática de salas habilitada');
    console.log('📝 Logs detalhados para debug');
});
