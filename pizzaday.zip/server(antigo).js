const express = require('express');
const path = require('path');

const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);

//Onde ficará o front do PizzaDay
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'public'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

app.use('/', (req, res) => {
    res.render('index.html');
});

let messages = [];

io.on('connection', socket => {
    console.log(`Socket conectado ${socket.id}`);

    socket.emit('previousMessages', messages);

    // Ouve o evento 'joinRoom' enviado pelo cliente
    socket.on('joinRoom', roomId => {
        // Usa o método join() para colocar o socket na sala com o ID fornecido
        socket.join(roomId);
        console.log(`Usuário entrou na sala: ${roomId}`);
        socket.emit('updateRoomId', roomId);
    });

    socket.on('sendMessage', data => {
        messages.push(data);
        socket.broadcast.emit('receivedMessage', data);
    });

})

server.listen(3000);